
"""
plot_acti.py

Gráfico de puntos de autocorrelación transformada (rho_x, rho_z).
"""
import matplotlib.pyplot as plt


def plot_acti(rhox, rhoz):
    plt.figure()
    plt.plot(rhox, rhoz, 'o', color='royalblue')
    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlabel("Autocorrelación objetivo $\rho_x$")
    plt.ylabel("Autocorrelación gaussiana $\rho_z$")
    plt.title("Transformación de autocorrelación")
    plt.grid(True)
    plt.show()
