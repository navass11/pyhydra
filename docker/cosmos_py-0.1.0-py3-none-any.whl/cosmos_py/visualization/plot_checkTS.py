"""
plot_checkTS.py

Port of R's plot.checkTS — boxplots of simulated statistics vs theoretical
expected values, one panel per statistic.
"""
import numpy as np
import matplotlib.pyplot as plt


def plot_check_ts(check_result, margdist=None, margarg=None, p0=None, ax=None):
    """
    Plot simulated statistics against theoretical expected values.

    Mirrors R's ``plot.checkTS``: one boxplot panel per statistic, with a red
    dot marking the expected value.

    Parameters
    ----------
    check_result : pd.DataFrame
        Output of :func:`cosmos_py.timeseries.checkTS.checkTS`.
        Index must contain ``"expected"`` as the first row; remaining rows are
        simulated realisations.
    margdist : str, optional
        Distribution name for the subtitle.
    margarg : dict, optional
        Distribution parameters for the subtitle.
    p0 : float, optional
        Probability zero for the subtitle.
    ax : ignored
        Kept for API consistency; this function always creates its own figure.

    Returns
    -------
    fig
    """
    expected = check_result.loc["expected"]
    simulated = check_result.drop(index="expected")
    stats = list(check_result.columns)
    n_stats = len(stats)

    fig, axes = plt.subplots(1, n_stats, figsize=(2.2 * n_stats, 4))
    if n_stats == 1:
        axes = [axes]

    for ax_i, stat in zip(axes, stats):
        sim_vals = simulated[stat].values.astype(float)
        exp_val  = float(expected[stat])

        # Boxplot of simulated values
        bp = ax_i.boxplot(sim_vals, widths=0.5, patch_artist=True,
                          boxprops=dict(facecolor="lightsteelblue", color="steelblue"),
                          medianprops=dict(color="steelblue", lw=1.5),
                          whiskerprops=dict(color="steelblue"),
                          capprops=dict(color="steelblue"),
                          flierprops=dict(marker="o", color="steelblue",
                                         markersize=3, alpha=0.5))
        # Red dot: expected value
        ax_i.scatter([1], [exp_val], color="firebrick", zorder=5,
                     s=60, label="Expected")

        ax_i.set_title(stat, fontsize=10,
                       color="white",
                       bbox=dict(facecolor="#404040", pad=3))
        ax_i.set_xticks([])
        ax_i.set_xlabel("")

    # Subtitle
    subtitle_parts = []
    if margdist:
        subtitle_parts.append(f"Marginal = {margdist}")
    if margarg:
        subtitle_parts.append(
            ";  ".join(f"{k} = {v}" for k, v in margarg.items())
        )
    if p0 is not None:
        subtitle_parts.append(f"p0 = {p0}")
    subtitle = "\n".join(subtitle_parts)

    fig.suptitle(subtitle if subtitle else "checkTS", fontsize=10, y=1.02)
    handles = [plt.Line2D([0], [0], marker="o", color="w",
                           markerfacecolor="firebrick", markersize=8,
                           label="Expected")]
    fig.legend(handles=handles, loc="upper right", fontsize=9, frameon=False)
    fig.tight_layout()
    return fig
