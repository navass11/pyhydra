
"""
plot_cosmosts.py

Visualización de series temporales generadas vs observadas.
"""
import matplotlib.pyplot as plt
import pandas as pd


def plot_cosmosts(observed, simulated):
    fig, axs = plt.subplots(2, 1, figsize=(12, 6), sharex=True)
    axs[0].plot(observed['date'], observed['value'])
    axs[0].set_title("Observed")

    axs[1].plot(simulated['date'], simulated['value'])
    axs[1].set_title("Simulated")

    for ax in axs:
        ax.grid(True)

    plt.tight_layout()
    plt.show()
