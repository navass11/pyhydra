"""
plot_fitDist.py

Port of R's plot.fitDist — empirical CDF vs fitted theoretical CDF on a
log-exceedance-probability scale.
"""
import numpy as np
import matplotlib.pyplot as plt


def _cdf(dist, params_dict, x):
    """Dispatch CDF for supported distributions."""
    x = np.asarray(x, dtype=float)
    if dist in ("gengamma", "ggamma"):
        from cosmos_py.distributions.ggamma import pggamma
        return pggamma(x, **params_dict)
    if dist == "paretoII":
        from cosmos_py.distributions.paretoII import pparetoII
        return pparetoII(x, **params_dict)
    if dist == "burrXII":
        from cosmos_py.distributions.burrXII import pburrXII
        return pburrXII(x, **params_dict)
    if dist == "burrIII":
        from cosmos_py.distributions.burrIII import pburrIII
        return pburrIII(x, **params_dict)
    if dist == "gev":
        from cosmos_py.distributions.gev import pgev
        return pgev(x, **params_dict)
    import scipy.stats as _st
    dist_obj = getattr(_st, dist)
    return dist_obj.cdf(x, **params_dict)


def plot_fit_dist(fit_result, ax=None, title=None):
    """
    Plot empirical CDF vs fitted theoretical CDF on a log-exceedance scale.

    Mirrors R's ``plot.fitDist``.

    Parameters
    ----------
    fit_result : dict
        Output of :func:`cosmos_py.utils.fitDist.fit_dist`.
    ax : matplotlib.axes.Axes, optional
        Axes to draw on. A new figure is created if None.
    title : str, optional
        Override the default title.

    Returns
    -------
    fig, ax
    """
    edf         = fit_result["edf"]
    dist        = fit_result["dist"]
    params_dict = fit_result["params_dict"]
    objective   = fit_result["objective"]

    emp_x = np.asarray(edf["x"], dtype=float)
    emp_p = np.asarray(edf["p"], dtype=float)

    # Theoretical CDF over the observed range (log-spaced probabilities)
    p_lo = float(np.clip(_cdf(dist, params_dict, emp_x.min()), 1e-6, 1 - 1e-6))
    p_hi = float(np.clip(_cdf(dist, params_dict, emp_x.max()), 1e-6, 1 - 1e-6))
    th_p = np.exp(np.linspace(np.log(p_lo), np.log(p_hi), 2000))
    th_p = np.clip(th_p, 1e-6, 1 - 1e-6)

    # Quantile function to map probabilities → values for the curve
    if dist in ("gengamma", "ggamma"):
        from cosmos_py.distributions.ggamma import qggamma
        th_x = qggamma(th_p, **params_dict)
    elif dist == "paretoII":
        from cosmos_py.distributions.paretoII import qparetoII
        th_x = qparetoII(th_p, **params_dict)
    elif dist == "burrXII":
        from cosmos_py.distributions.burrXII import qburrXII
        th_x = qburrXII(th_p, **params_dict)
    elif dist == "burrIII":
        from cosmos_py.distributions.burrIII import qburrIII
        th_x = qburrIII(th_p, **params_dict)
    elif dist == "gev":
        from cosmos_py.distributions.gev import qgev
        th_x = qgev(th_p, **params_dict)
    else:
        import scipy.stats as _st
        th_x = getattr(_st, dist).ppf(th_p, **params_dict)

    th_y = np.log(1.0 - th_p)
    emp_y = np.log(1.0 - emp_p)

    if ax is None:
        fig, ax = plt.subplots(figsize=(6, 5))
    else:
        fig = ax.get_figure()

    ax.plot(th_x, th_y, color="grey", lw=1.5, alpha=0.85, label="Theoretical")
    ax.scatter(emp_x, emp_y, color="firebrick", s=18, alpha=0.6, zorder=3,
               label="Empirical")

    # Y-axis: show exceedance probabilities, not log values
    yticks = np.linspace(th_y.min(), 0, 5)
    ax.set_yticks(yticks)
    ax.set_yticklabels([f"{np.exp(y):.1e}" for y in yticks])

    ax.set_xlabel("Nonzero values")
    ax.set_ylabel("Exceedance probability")
    if title is None:
        title = f"fitDist — {dist}  (error = {objective:.5f})"
    ax.set_title(title)
    ax.legend(fontsize=9)
    fig.tight_layout()
    return fig, ax
