
"""
quickTSPlot.py

Gráficas básicas de series temporales: línea, histograma, ACF.
"""
import matplotlib.pyplot as plt
import statsmodels.api as sm


def quick_ts_plot(series, ci=0.95):
    fig, axs = plt.subplots(3, 1, figsize=(10, 8))

    axs[0].plot(series)
    axs[0].set_title("Time Series")

    axs[1].hist(series, bins=50, color='steelblue', edgecolor='black')
    axs[1].set_title("Histogram")

    sm.graphics.tsa.plot_acf(series, ax=axs[2], alpha=1 - ci)
    axs[2].set_title("Autocorrelation")

    plt.tight_layout()
    plt.show()
