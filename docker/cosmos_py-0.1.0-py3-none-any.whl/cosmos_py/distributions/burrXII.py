import numpy as np
from scipy.special import beta as beta_func


def dburrXII(x, scale, shape1, shape2, log=False):
    if shape1 <= 0 or shape2 <= 0 or scale <= 0:
        return np.full(np.asarray(x).shape, np.nan) if np.ndim(x) > 0 else np.nan

    x = np.asarray(x, dtype=np.float64)
    with np.errstate(divide='ignore', invalid='ignore', over='ignore'):
        z = x / scale
        log_d = (
            (shape1 - 1) * np.log(z) +
            (-1 - 1.0 / (shape1 * shape2)) * np.log1p(shape2 * z ** shape1) -
            np.log(scale)
        )
        result = log_d if log else np.exp(log_d)
        return result


def pburrXII(q, scale, shape1, shape2, lower_tail=True, log_p=False):
    if shape1 <= 0 or shape2 <= 0 or scale <= 0:
        return np.nan

    q = np.asarray(q, dtype=np.float64)
    z = q / scale
    p = 1.0 - (1.0 + shape2 * z ** shape1) ** (-1.0 / (shape1 * shape2))

    if not lower_tail:
        p = 1.0 - p
    if log_p:
        p = np.log(p)
    return p


def qburrXII(p, scale, shape1, shape2, lower_tail=True, log_p=False):
    if shape1 <= 0 or shape2 <= 0 or scale <= 0:
        return np.nan

    p = np.asarray(p, dtype=np.float64)
    if not lower_tail:
        p = 1.0 - p
    if log_p:
        p = np.exp(p)
    p = np.clip(p, 1e-15, 1 - 1e-15)
    return scale * (((1.0 - p) ** (-(shape1 * shape2)) - 1.0) / shape2) ** (1.0 / shape1)


def rburrXII(n, scale, shape1, shape2):
    if shape1 <= 0 or shape2 <= 0 or scale <= 0:
        return np.nan
    return qburrXII(np.random.uniform(size=n), scale, shape1, shape2)


def mburrXII(r, scale, shape1, shape2):
    if shape1 <= 0 or shape2 <= 0 or scale <= 0:
        return np.nan
    return (
        scale ** r *
        shape2 ** (-1.0 - r / shape1) *
        beta_func((r + shape1) / shape1, (1.0 - r * shape2) / (shape1 * shape2))
    ) / shape1
