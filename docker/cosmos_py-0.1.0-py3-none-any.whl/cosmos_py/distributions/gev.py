import numpy as np
from scipy.integrate import quad


def dgev(x, loc, scale, shape, log=False):
    x = np.asarray(x, dtype=np.float64)
    z = (x - loc) / scale

    if shape == 0:
        with np.errstate(over='ignore'):
            log_d = -np.log(scale) - z - np.exp(-z)
    else:
        t = 1.0 + shape * z
        valid = t > 0
        log_d = np.full_like(x, -np.inf)
        tv = t[valid]
        log_d[valid] = (
            -np.log(scale) -
            tv ** (-1.0 / shape) -
            (1.0 / shape + 1.0) * np.log(tv)
        )

    if log:
        return log_d
    return np.exp(log_d)


def pgev(q, loc, scale, shape, lower_tail=True, log_p=False):
    q = np.asarray(q, dtype=np.float64)

    if shape == 0:
        t = (q - loc) / scale
    else:
        with np.errstate(divide='ignore', invalid='ignore'):
            arg = np.maximum(0.0, 1.0 - shape * (q - loc) / scale)
            t = -1.0 / shape * np.log(arg)
            # where arg==0, t → +inf (upper bound for shape>0), CDF→1
            t = np.where(arg <= 0, np.inf, t)

    p = np.exp(-np.exp(-t))

    if not lower_tail:
        p = 1.0 - p
    if log_p:
        p = np.log(p)
    return p


def qgev(p, loc, scale, shape, lower_tail=True, log_p=False):
    p = np.asarray(p, dtype=np.float64)
    if not lower_tail:
        p = 1.0 - p
    if log_p:
        p = np.exp(p)

    if shape == 0:
        return loc - scale * np.log(-np.log(p))
    return loc + scale / shape * (1.0 - (-np.log(p)) ** shape)


def rgev(n, loc, scale, shape):
    return qgev(np.random.uniform(size=n), loc, scale, shape)


def mgev(r, loc, scale, shape):
    if scale == 0:
        return np.nan

    integrand = lambda x: x ** r * float(dgev(np.array([x]), loc, scale, shape))

    if shape == 0:
        lwr, upr = -np.inf, np.inf
    elif loc > 0 and shape > 0:
        lwr = loc - scale / shape
        upr = np.inf
    elif loc > 0 and shape < 0:
        lwr = -np.inf
        upr = loc - scale / shape
    else:
        lwr, upr = -np.inf, np.inf

    result, _ = quad(integrand, lwr, upr, limit=200)
    return result
