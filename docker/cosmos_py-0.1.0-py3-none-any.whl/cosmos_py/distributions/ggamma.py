import numpy as np
from scipy.special import gamma as gamma_func
from scipy.stats import gamma as gamma_dist


def dggamma(x, scale, shape1, shape2, log=False):
    if shape1 <= 0 or shape2 <= 0 or scale <= 0:
        return np.full(np.asarray(x).shape, np.nan) if np.ndim(x) > 0 else np.nan

    x = np.asarray(x, dtype=np.float64)
    with np.errstate(divide='ignore', invalid='ignore', over='ignore'):
        z = x / scale
        log_dens = (
            np.log(shape2) +
            (shape1 - 1) * np.log(z) -
            z ** shape2 -
            np.log(scale) -
            np.log(gamma_func(shape1 / shape2))
        )
        result = log_dens if log else np.exp(log_dens)
        return np.where(np.isfinite(result), result, np.nan)


def pggamma(q, scale, shape1, shape2, lower_tail=True, log_p=False):
    if scale <= 0 or shape1 <= 0 or shape2 <= 0:
        return np.nan

    q = np.asarray(q, dtype=np.float64)
    z = np.clip((q / scale) ** shape2, 1e-300, 1e300)

    with np.errstate(divide='ignore', invalid='ignore'):
        p = gamma_dist.cdf(z, a=shape1 / shape2, scale=1)

    if not lower_tail:
        p = 1.0 - p
    if log_p:
        p = np.log(np.clip(p, 1e-300, 1.0))
    return p


def qggamma(p, scale, shape1, shape2, lower_tail=True, log_p=False):
    if shape1 <= 0 or shape2 <= 0 or scale <= 0:
        return np.nan

    p = np.asarray(p, dtype=np.float64)
    if not lower_tail:
        p = 1.0 - p
    if log_p:
        p = np.exp(p)
    p = np.clip(p, 1e-10, 1 - 1e-10)
    return scale * gamma_dist.ppf(p, a=shape1 / shape2, scale=1) ** (1.0 / shape2)


def rggamma(n, scale, shape1, shape2):
    if shape1 <= 0 or shape2 <= 0 or scale <= 0:
        return np.nan
    from scipy.stats import norm
    return qggamma(norm.cdf(np.random.randn(n)), scale, shape1, shape2)


def mggamma(r, scale, shape1, shape2):
    if shape1 <= 0 or shape2 <= 0 or scale <= 0:
        return np.nan
    return (scale ** r * gamma_func(r / shape2 + shape1 / shape2)) / gamma_func(shape1 / shape2)
