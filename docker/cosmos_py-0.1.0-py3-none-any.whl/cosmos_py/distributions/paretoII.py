import numpy as np
from scipy.stats import rv_continuous
from scipy.special import gamma


# ── Standalone functions (matching R parameter names) ────────────────────────

def dparetoII(x, scale, shape, log=False):
    if scale <= 0 or shape <= 0:
        return np.full(np.asarray(x).shape, np.nan) if np.ndim(x) > 0 else np.nan
    x = np.asarray(x, dtype=np.float64)
    d = (1.0 + shape * x / scale) ** (-1.0 - 1.0 / shape) / scale
    return np.log(d) if log else d


def pparetoII(q, scale, shape, lower_tail=True, log_p=False):
    if scale <= 0 or shape <= 0:
        return np.nan
    q = np.asarray(q, dtype=np.float64)
    p = 1.0 - (1.0 + shape * q / scale) ** (-1.0 / shape)
    if not lower_tail:
        p = 1.0 - p
    if log_p:
        p = np.log(p)
    return p


def qparetoII(p, scale, shape, lower_tail=True, log_p=False):
    if scale <= 0 or shape <= 0:
        return np.nan
    p = np.asarray(p, dtype=np.float64)
    if not lower_tail:
        p = 1.0 - p
    if log_p:
        p = np.exp(p)
    return (scale * (-1.0 + (1.0 - p) ** (-shape))) / shape


def rparetoII(n, scale, shape):
    if scale <= 0 or shape <= 0:
        return np.nan
    return qparetoII(np.random.uniform(size=n), scale, shape)


def mparetoII(r, scale, shape):
    if scale <= 0 or shape <= 0:
        return np.nan
    return (scale / shape) ** r * gamma(1.0 / shape - r) * gamma(1.0 + r) / gamma(1.0 / shape)


class paretoII_gen(rv_continuous):
    """Pareto type II distribution (Lomax) personalizada para CoSMoS."""

    def _argcheck(self, scale_param, shape):
        return (scale_param > 0) & (shape > 0)

    def _pdf(self, x, scale_param, shape):
        return ((1 + (shape * x) / scale_param) ** (-1 - 1 / shape)) / scale_param

    def _cdf(self, x, scale_param, shape):
        return 1 - (1 + (shape * x) / scale_param) ** (-1 / shape)

    def _ppf(self, p, scale_param, shape):
        return (scale_param * (-1 + (1 - p) ** (-shape))) / shape

    def _rvs(self, scale_param, shape):
        u = self._random_state.uniform(size=self._size)
        return (scale_param * (-1 + (1 - u) ** (-shape))) / shape

    def _mom1(self, r, scale_param, shape):
        return ((scale_param / shape) ** r * gamma(1 / shape - r) * gamma(1 + r)) / gamma(1 / shape)

    def moment(self, order, scale_param, shape):
        if shape <= 0 or scale_param <= 0:
            return np.nan
        try:
            return self._mom1(order, scale_param, shape)
        except Exception:
            return np.nan


# Instanciar la distribución con nombre 'paretoII'
paretoII = paretoII_gen(a=0, name="paretoII")