#from cosmos_py.utils.ecdf import compute_ecdf 
from cosmos_py.distributions.ggamma import *
from scipy import stats
from typing import Dict, List, Union, Optional
from cosmos_py.utils.ecdf import compute_ecdf  # Suponiendo que tengas una función ECDF
import pandas as pd
from scipy.stats import norm as normal

def get_dist_args(dist_name: str) -> List[str]:
    """
    Obtiene los nombres de los parámetros para una distribución dada
    
    Args:
        dist_name: Nombre de la distribución
        
    Returns:
        Lista de nombres de parámetros
    """
    dist_params = {
        'norm': ['loc', 'scale'],
        'beta': ['a', 'b', 'loc', 'scale'],
        'gamma': ['a', 'loc', 'scale'],
        'burr': ['c', 'd', 'loc', 'scale'],
        'burr12': ['c', 'd', 'loc', 'scale'],
        'gengamma': ['shape1', 'shape2', 'scale']
    }
    
    if dist_name not in dist_params:
        raise ValueError(f"Distribución no reconocida: '{dist_name}'. "
                       f"Distribuciones soportadas: {list(dist_params.keys())}")
    
    return dist_params[dist_name]

def norm_objective(par, val, dist='gengamma', norm='N2', n_points=30):
    """
    Función objetivo para el ajuste de distribuciones usando normas N1–N4.

    Args:
        par: lista de parámetros de la distribución
        val: valores empíricos
        dist: nombre de la distribución ('gengamma', 'norm', etc.)
        norm: norma a usar ('N1', 'N2', 'N3', 'N4')
        n_points: número de puntos para la comparación ECDF

    Returns:
        Error (float) a minimizar
    """
    if np.any(np.isnan(par)) or np.any(np.isinf(par)):
        return 1e10

    val = np.asarray(val)
    par = np.asarray(par)

    # Asignar parámetros según la distribución
    if dist == 'gengamma':
        scale, shape1, shape2,  = par
        if shape1 <= 0 or shape2 <= 0 or scale <= 0:
            return 1e10
    elif dist == 'norm':
        loc, scale = par
        if scale <= 0:
            return 1e10
    else:
        return 1e10

    # 1. ECDF con método 'first' (como en R)
    ecdf = compute_ecdf(val)
    x_sorted = ecdf['x']
    p_sorted = ecdf['p']

    # 2. Selección de puntos
    n = len(x_sorted)
    sel_idx = np.linspace(0, n - 1, min(n_points, n)).astype(int)
    sel_idx = np.unique(sel_idx)  # evitar duplicados

    sampled_values = x_sorted[sel_idx]
    sampled_p = np.clip(p_sorted[sel_idx], 1e-6, 1 - 1e-6)

    try:
        # 3. Norma N1/N2 (cuantiles)
        if norm in ['N1', 'N2']:
            if dist == 'norm':
                theo = normal.ppf(sampled_p, loc=loc, scale=scale)
            elif dist == 'gengamma':
                theo = qggamma(sampled_p, scale=scale, shape1=shape1, shape2=shape2)
            else:
                return 1e10
            err = np.mean((sampled_values - theo) ** 2)
            return np.sqrt(err) if norm == 'N1' else err

        # 4. Norma N3/N4 (probabilidades)
        elif norm in ['N3', 'N4']:
            if dist == 'norm':
                theo = normal.cdf(sampled_values, loc=loc, scale=scale)
            elif dist == 'gengamma':
                theo = pggamma(sampled_values, scale=scale, shape1=shape1, shape2=shape2)
            else:
                return 1e10
            err = np.mean((theo - sampled_p) ** 2)
            return np.sqrt(err) if norm == 'N3' else err

    except Exception:
        return 1e10

    return 1e10