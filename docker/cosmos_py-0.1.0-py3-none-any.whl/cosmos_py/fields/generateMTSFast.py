"""
generateMTSFast — fast multivariate TS simulation via DHM circulant-embedding.

Port of generateMTSFast from generate-fields.R.
Identical algorithm to generateRFFast but accepts irregular coordinates.

Reference:
  Serinaldi & Kilsby (2018), WRR 54(9), 6460-6487
  Papalexiou & Serinaldi (2020), WRR 56(2), e2019WR026331
"""
import numpy as np
from scipy.spatial.distance import squareform, pdist
from scipy.stats import norm as _norm, t as _student, chi2 as _chi2

from cosmos_py.fields.anisotropyT import anisotropy_T2
from cosmos_py.correlation.acs import get_acs
from cosmos_py.correlation.acti import actpnts, fitactf, actf, actf_inv
from cosmos_py.utils.dhm import dhm_gen_sj, dhm_gen_sim
from cosmos_py.fields._simulate_var import FieldResult, _ppf_marginal
from cosmos_py.fields.fitVAR import _nearest_pd_corr
from cosmos_py.fields.generateRFFast import _is_pd


def generate_mts_fast(n, spacepoints, margdist, margarg, p0,
                      distbounds=(-np.inf, np.inf),
                      stcsarg=None,
                      scalefactor=1,
                      anisotropyid="affine",
                      anisotropyarg=None,
                      dsid="gauss", dsarg=None):
    """
    Fast simulation of multiple time series via DHM circulant-embedding.

    Parameters
    ----------
    n : int
        Number of time steps.
    spacepoints : ndarray (d x 2)
        Coordinates of d spatial locations (e.g. gauge stations).
    Other parameters same as generate_rf_fast.

    Returns
    -------
    FieldResult, shape (n, d)
    """
    if stcsarg is None:
        stcsarg = {}
    if anisotropyarg is None:
        anisotropyarg = {"phi1": 1, "phi2": 1, "phi12": 0, "theta": 0}

    dd0 = np.asarray(spacepoints, dtype=float)
    if dd0.ndim != 2 or dd0.shape[1] != 2:
        raise ValueError("spacepoints must be a (d x 2) array")
    mm = dd0.shape[0]

    aniso_args = dict(anisotropyarg)
    aniso_args["spacepoints"] = dd0
    dd = anisotropy_T2(anisotropyid, aniso_args)
    dis = squareform(pdist(dd))

    # ── ACTF calibration ─────────────────────────────────────────────────────
    if dsid in ("gauss", "student"):
        pnts = actpnts(margdist=margdist, margarg=margarg, p0=p0,
                       distbounds=distbounds)
    else:
        raise NotImplementedError(f"dsid='{dsid}' not supported in generate_mts_fast")

    actfpara = fitactf(pnts)
    b = actfpara["actfcoef"]["b"]
    c = actfpara["actfcoef"]["c"]

    # ── Spatial correlation matrix ────────────────────────────────────────────
    scfid  = stcsarg.get("scfid", "weibull")
    scfarg = stcsarg.get("scfarg", {})
    raw_scf = get_acs(scfid, t=dis, **scfarg)
    scf = actf(np.asarray(raw_scf, dtype=float), b, c)
    if not _is_pd(np.round(scf, 6)):
        scf = _nearest_pd_corr(scf)

    # ── Temporal autocorrelation ──────────────────────────────────────────────
    tcfid  = stcsarg.get("tcfid", "weibull")
    tcfarg = stcsarg.get("tcfarg", {})
    t_lags = np.arange(n + 1)
    raw_tcf = get_acs(tcfid, t=t_lags.astype(float), **tcfarg)
    tcf = actf(np.asarray(raw_tcf, dtype=float), b, c)

    # ── DHM simulation ────────────────────────────────────────────────────────
    Sj = dhm_gen_sj(tcf)
    n_draws = 2 * len(Sj) - 2
    rn = np.random.multivariate_normal(np.zeros(mm), scf, size=n_draws)

    out = np.zeros((mm, n))
    for i in range(mm):
        out[i, :] = dhm_gen_sim(Sj, rn=rn[:, i])
    x = out.T   # (n, mm)

    # ── CDF transform ─────────────────────────────────────────────────────────
    if dsid == "gauss":
        x = _norm.cdf(x, loc=np.mean(x), scale=np.std(x, ddof=1))
    elif dsid == "student":
        nu = float(dsarg)
        S  = _chi2.rvs(nu, size=n)
        x  = _student.cdf(x * np.sqrt(nu / S[:, None]), nu)

    # ── Intermittency + marginal quantile ─────────────────────────────────────
    x_out = np.zeros_like(x)
    mask = x > p0
    if np.any(mask):
        u = (x[mask] - p0) / (1.0 - p0)
        x_out[mask] = _ppf_marginal(u, margdist, margarg)

    # ── Diagnostic STCS ───────────────────────────────────────────────────────
    d_lags = np.linspace(0, dis.max(), 200) if dis.max() > 0 else np.array([0.0])
    scf0 = actf(np.asarray(get_acs(scfid, t=d_lags, **scfarg), dtype=float), b, c)
    tcf0 = actf(np.asarray(get_acs(tcfid, t=t_lags.astype(float), **tcfarg), dtype=float), b, c)
    fout = actf_inv(np.outer(tcf0, scf0), b, c)

    STmodel = {
        "margdist":  margdist,
        "margarg":   margarg,
        "p0":        p0,
        "stcs":      fout,
        "s_lags":    d_lags,
        "t_lags":    t_lags,
        "grid_lags": dis,
    }
    return FieldResult(x_out, STmodel=STmodel)
