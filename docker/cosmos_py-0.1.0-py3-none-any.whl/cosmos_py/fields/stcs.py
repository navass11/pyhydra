"""
Spatio-Temporal Correlation Structure (STCS) functions.

Port of stcs.r — clayton, gneiting14, gneiting16.
References:
  Papalexiou & Serinaldi (2020), WRR 56(2), e2019WR026331
  Papalexiou, Serinaldi, Porcu (2021), WRR 57, e2020WR029466
  Gneiting (2002), JASA 97:458, 590-600
"""
import numpy as np
from scipy.special import gamma as gamma_func
from scipy.special import kv as besselK

from cosmos_py.correlation.acs import get_acs


def stcs(id, t, s, **kwargs):
    """Dispatcher for spatio-temporal correlation structure functions."""
    dispatch = {
        "clayton":    stcfclayton,
        "gneiting14": stcfgneiting14,
        "gneiting16": stcfgneiting16,
    }
    if id not in dispatch:
        raise ValueError(f"Unknown STCS id: '{id}'")
    return dispatch[id](t=t, s=s, **kwargs)


def stcs2(id, arglist):
    """Internal dispatcher that takes an argument dict (mirrors R's stcs2)."""
    arglist = dict(arglist)
    return stcs(id, **arglist)


def stcfclayton(t, s, scfid, tcfid, copulaarg, scfarg, tcfarg):
    """
    Clayton copula-based spatio-temporal correlation structure.

    Marginal spatial and temporal correlation functions are combined via a
    Clayton copula:
        STCF = (TCF^(-theta) + SCF^(-theta) - 1)^(-1/theta)   if theta > 0
        STCF = TCF * SCF                                        if theta == 0
    """
    if copulaarg < 0:
        return np.full_like(np.asarray(s, dtype=float), np.nan)

    scf = get_acs(scfid, t=np.asarray(s, dtype=float), **scfarg)
    tcf = get_acs(tcfid, t=np.asarray(t, dtype=float), **tcfarg)

    if copulaarg == 0:
        return tcf * scf
    return (tcf ** (-copulaarg) + scf ** (-copulaarg) - 1.0) ** (-1.0 / copulaarg)


def stcfgneiting14(t, s, a, c, alpha, beta, gamma, tau):
    """
    Gneiting (2002) Eq.14 spatio-temporal correlation structure.

    Parameters
    ----------
    a : nonneg scaling of time
    c : nonneg scaling of space
    alpha : smoothness of time in (0, 1]
    gamma : smoothness of space in (0, 1]
    beta : space-time interaction in [0, 1]
    tau : >= 1 (for 2-D fields)
    """
    t = np.asarray(t, dtype=float)
    s = np.asarray(s, dtype=float)
    if (a < 0 or c < 0 or not (0 < alpha <= 1) or
            not (0 <= beta <= 1) or not (0 < gamma <= 1) or tau < 1):
        return np.full(np.broadcast(t, s).shape, np.nan)
    denom = a * np.abs(t) ** (2 * alpha) + 1.0
    return (1.0 / denom ** tau) * np.exp(
        -(c * np.abs(s) ** (2 * gamma)) / denom ** (beta * gamma)
    )


def stcfgneiting16(t, s, a, c, alpha, beta, nu, tau):
    """
    Gneiting (2002) Eq.16 spatio-temporal correlation structure (Matern).

    Parameters
    ----------
    nu : Matern smoothness > 0
    Other parameters same as stcfgneiting14 except gamma replaced by nu.
    """
    t = np.asarray(t, dtype=float)
    s = np.asarray(s, dtype=float)
    if (a < 0 or c < 0 or not (0 < alpha <= 1) or
            not (0 <= beta <= 1) or nu <= 0 or tau < 1):
        return np.full(np.broadcast(t, s).shape, np.nan)

    denom = a * np.abs(t) ** (2 * alpha) + 1.0
    arg = c * np.abs(s) / denom ** (beta / 2.0)

    # At arg=0, the Matern formula has limit: 1 / denom^tau
    # (arg^nu * besselK(nu, arg) → 2^(nu-1)*Gamma(nu) as arg→0)
    factor = 1.0 / (2.0 ** (nu - 1) * gamma_func(nu) * denom ** tau)
    with np.errstate(invalid="ignore"):
        matern_vals = factor * np.where(arg > 0, arg, 1.0) ** nu * besselK(nu, np.where(arg > 0, arg, 1.0))
    matern = np.where(arg == 0, 1.0 / denom ** tau, matern_vals)
    return matern
