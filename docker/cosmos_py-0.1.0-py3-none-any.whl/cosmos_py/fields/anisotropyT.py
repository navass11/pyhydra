"""
Anisotropy transformation functions.

Port of anisotropyT.R — affine, swirl, and wave deformation fields.
Reference: Papalexiou, Serinaldi, Porcu (2021), WRR 57, e2020WR029466.
"""
import numpy as np


def anisotropy_T(id, spacepoints, **kwargs):
    """Dispatcher for anisotropy transformations."""
    dispatch = {
        "affine": anisotropy_T_affine,
        "swirl":  anisotropy_T_swirl,
        "wave":   anisotropy_T_wave,
    }
    if id not in dispatch:
        raise ValueError(f"Unknown anisotropy id: '{id}'")
    return dispatch[id](spacepoints=spacepoints, **kwargs)


def anisotropy_T2(id, arglist):
    """Internal dispatcher that takes an argument dict (mirrors R's anisotropyT2)."""
    arglist = dict(arglist)
    return anisotropy_T(id, **arglist)


def anisotropy_T_affine(spacepoints, phi1, phi2, phi12, theta):
    """
    Affine anisotropy transformation (rotation + stretching).

    R formula:
        The <- matrix(c(cos(theta), sin(theta), -sin(theta), cos(theta)), ncol=2)
        Phi <- matrix(c(phi1, phi12, phi12, phi2), ncol=2)
        t(Phi %*% The %*% t(spacepoints))
    """
    spacepoints = np.asarray(spacepoints, dtype=float)
    # Rotation matrix (filled column-major in R, so col1=[cos,-sin], col2=[sin,cos])
    The = np.array([[np.cos(theta), -np.sin(theta)],
                    [np.sin(theta),  np.cos(theta)]])
    # Stretching/shear matrix (col1=[phi1,phi12], col2=[phi12,phi2])
    Phi = np.array([[phi1, phi12],
                    [phi12, phi2]])
    return (Phi @ The @ spacepoints.T).T


def anisotropy_T_swirl(spacepoints, x0, y0, b, alpha):
    """
    Swirl anisotropy transformation.

    Each point is rotated by an angle that decreases with distance from (x0, y0).
    """
    spacepoints = np.asarray(spacepoints, dtype=float)
    x = spacepoints[:, 0]
    y = spacepoints[:, 1]
    r = np.sqrt((x - x0) ** 2 + (y - y0) ** 2)
    theta = alpha * np.exp(-(r / b) ** 2)
    xani = (x - x0) * np.cos(theta) - (y - y0) * np.sin(theta) + x0
    yani = (x - x0) * np.sin(theta) + (y - y0) * np.cos(theta) + y0
    return np.column_stack([xani, yani])


def anisotropy_T_wave(spacepoints, phi1, phi2, beta, theta):
    """
    Wave anisotropy transformation (sinusoidal distortion).
    """
    spacepoints = np.asarray(spacepoints, dtype=float)
    x = spacepoints[:, 0]
    y = spacepoints[:, 1]
    xani = phi1 * x * np.cos(theta) - y * np.sin(theta)
    yani = x * np.sin(theta) + phi1 * y * np.cos(theta) + beta * np.sin(x)
    return np.column_stack([xani, yani])
