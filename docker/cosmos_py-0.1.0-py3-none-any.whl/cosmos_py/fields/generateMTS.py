"""
generateMTS — simulate multiple time series from a fitted VAR model.

Port of generateMTS from generate-fields.R.
Output shape: (n, mm) — rows = time steps, columns = spatial locations.
"""
from cosmos_py.fields._simulate_var import simulate_var


def generate_mts(n, STmodel):
    """
    Simulate n time steps of a multivariate time series from a fitted VAR model.

    Parameters
    ----------
    n : int
        Number of time steps to simulate.
    STmodel : dict
        Output of fit_var().

    Returns
    -------
    FieldResult, shape (n, mm)
        Rows are time steps; columns are spatial locations.
        Carries .STmodel attribute.
    """
    return simulate_var(n, STmodel)
