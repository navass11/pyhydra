"""
Advection field functions.

Port of advectionF.R — uniform, rotation, spiral, spiralCE, radial, hyperbolic.
Reference: Papalexiou, Serinaldi, Porcu (2021), WRR 57, e2020WR029466.

All functions return an (d x 2) numpy array of (u, v) velocity components,
where d is the number of spatial locations.
"""
import numpy as np


def advection_F(id, spacepoints, **kwargs):
    """Dispatcher for advection field types."""
    dispatch = {
        "uniform":    advection_F_uniform,
        "rotation":   advection_F_rotation,
        "spiral":     advection_F_spiral,
        "spiralCE":   advection_F_spiral_ce,
        "radial":     advection_F_radial,
        "hyperbolic": advection_F_hyperbolic,
    }
    if id not in dispatch:
        raise ValueError(f"Unknown advection id: '{id}'")
    return dispatch[id](spacepoints=spacepoints, **kwargs)


def advection_F2(id, arglist):
    """Internal dispatcher that takes an argument dict (mirrors R's advectionF2)."""
    arglist = dict(arglist)
    return advection_F(id, **arglist)


def advection_F_uniform(spacepoints, u, v):
    """Uniform (constant) advection field."""
    spacepoints = np.asarray(spacepoints, dtype=float)
    d = spacepoints.shape[0]
    return np.column_stack([np.full(d, u), np.full(d, v)])


def advection_F_rotation(spacepoints, x0, y0, a, b):
    """Rotational advection around (x0, y0)."""
    spacepoints = np.asarray(spacepoints, dtype=float)
    x = spacepoints[:, 0] - x0
    y = spacepoints[:, 1] - y0
    return np.column_stack([a * y, -b * x])


def advection_F_spiral(spacepoints, x0, y0, a, b, rotation=1):
    """Spiraling advection toward/from (x0, y0)."""
    spacepoints = np.asarray(spacepoints, dtype=float)
    x = spacepoints[:, 0] - x0
    y = spacepoints[:, 1] - y0
    if rotation == 1:
        u = b * y - a * x
        v = -a * x - b * y
    elif rotation == 2:
        u = -a * x - b * y
        v = a * x - b * y
    else:
        raise ValueError("rotation must be 1 or 2")
    return np.column_stack([u, v])


def advection_F_spiral_ce(spacepoints, a, C):
    """Spiraling advection satisfying continuity equation (Burkardt)."""
    spacepoints = np.asarray(spacepoints, dtype=float)
    xaux = spacepoints[:, 0]
    yaux = spacepoints[:, 1]
    rng_x = np.ptp(xaux)
    rng_y = np.ptp(yaux)
    x = (xaux - xaux.min()) / rng_x if rng_x > 0 else np.zeros_like(xaux)
    y = (yaux - yaux.min()) / rng_y if rng_y > 0 else np.zeros_like(yaux)
    dPPdx = (np.sin(C * np.pi * x) * (C * np.pi) * (1 - x) ** 2
             - (1 - np.cos(C * np.pi * x)) * 2 * (1 - x)) * (
             (1 - np.cos(C * np.pi * y)) * (1 - y) ** 2)
    dPPdy = ((1 - np.cos(C * np.pi * x)) * (1 - x) ** 2) * (
             np.sin(C * np.pi * y) * (C * np.pi) * (1 - y) ** 2
             - (1 - np.cos(C * np.pi * y)) * 2 * (1 - y))
    return np.column_stack([-a * dPPdy, a * dPPdx])


def advection_F_radial(spacepoints, x0, y0, a, b):
    """Radial advection diverging from / converging to (x0, y0)."""
    spacepoints = np.asarray(spacepoints, dtype=float)
    x = spacepoints[:, 0] - x0
    y = spacepoints[:, 1] - y0
    return np.column_stack([a * x, b * y])


def advection_F_hyperbolic(spacepoints, x0, y0, a, b):
    """Hyperbolic advection field."""
    spacepoints = np.asarray(spacepoints, dtype=float)
    x = spacepoints[:, 0] - x0
    y = spacepoints[:, 1] - y0
    return np.column_stack([a * y, b * x])
