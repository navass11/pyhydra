"""
Internal helper: VAR(p) simulation and marginal back-transformation.

Equivalent to R's simulate_var() in generate-fields.R.
"""
import numpy as np
from scipy.stats import norm as _norm, t as _student, chi2 as _chi2
from scipy.stats import rankdata


class FieldResult(np.ndarray):
    """ndarray subclass that carries an STmodel attribute (mirrors R's structure())."""
    _attrs = ("STmodel",)

    def __new__(cls, data, STmodel=None):
        obj = np.asarray(data).view(cls)
        obj.STmodel = STmodel
        return obj

    def __array_finalize__(self, obj):
        if obj is None:
            return
        self.STmodel = getattr(obj, "STmodel", None)


def _ppf_marginal(u, margdist, margarg):
    """Quantile function dispatcher for marginal back-transformation."""
    u = np.asarray(u, dtype=float)
    if margdist in ("gengamma", "ggamma"):
        from cosmos_py.distributions.ggamma import qggamma
        return qggamma(u, **margarg)
    if margdist == "paretoII":
        from cosmos_py.distributions.paretoII import qparetoII
        return qparetoII(u, **margarg)
    if margdist == "burrXII":
        from cosmos_py.distributions.burrXII import qburrXII
        return qburrXII(u, **margarg)
    if margdist == "burrIII":
        from cosmos_py.distributions.burrIII import qburrIII
        return qburrIII(u, **margarg)
    if margdist == "gev":
        from cosmos_py.distributions.gev import qgev
        return qgev(u, **margarg)
    raise ValueError(f"Unknown margdist: '{margdist}'")


def _mar_sim(n, alpha, res_cov, mm, p):
    """
    Simulate n observations from a VAR(p) model.

    Equivalent to mAr.sim(w=rep(0,mm), A=alpha, C=res_cov, N=n) in R.
    """
    try:
        L = np.linalg.cholesky(res_cov)
    except np.linalg.LinAlgError:
        L = np.linalg.cholesky(res_cov + 1e-8 * np.eye(mm))

    X = np.zeros((n + p, mm))
    for t in range(p, n + p):
        past = np.concatenate([X[t - i - 1] for i in range(p)])
        X[t] = alpha @ past + L @ np.random.randn(mm)
    return X[p:]   # (n, mm)


def simulate_var(n, STmodel):
    """
    Simulate from a fitted VAR model and apply marginal back-transformation.

    Returns FieldResult (ndarray subclass) of shape (n, mm) with .STmodel attr.
    """
    alpha    = np.asarray(STmodel["alpha"])
    res_cov  = np.asarray(STmodel["res_cov"])
    mm       = STmodel["mm"]
    p        = STmodel["p"]
    margdist = STmodel["margdist"]
    margarg  = STmodel["margarg"]
    p0       = STmodel["p0"]
    dsid     = STmodel.get("dsid", "gauss")
    dsarg    = STmodel.get("dsarg", None)

    x = _mar_sim(n, alpha, res_cov, mm, p)  # (n, mm)

    # ── CDF/copula transform ─────────────────────────────────────────────────
    if dsid == "gauss":
        x = _norm.cdf(x, loc=np.mean(x), scale=np.std(x, ddof=1))

    elif dsid == "student":
        nu = float(dsarg)
        S  = _chi2.rvs(nu, size=n)
        x  = _student.cdf(x * np.sqrt(nu / S[:, None]), nu)

    elif dsid in ("bardossy", "bardossyF"):
        m = float(dsarg)
        rng = np.random.default_rng(666)
        x_adj = (x - np.mean(x) + m) ** 2
        result = np.zeros_like(x)
        jitter_amt = 1.0 / (n + 1)
        for j in range(mm):
            ranks = rankdata(x_adj[:, j])
            result[:, j] = (ranks / (n + 1)
                            + rng.uniform(-jitter_amt, jitter_amt, size=n))
        x = 1.0 - result if dsid == "bardossyF" else result

    # ── Intermittency + marginal quantile ─────────────────────────────────────
    x_out = np.zeros_like(x)
    mask = x > p0
    if np.any(mask):
        u = (x[mask] - p0) / (1.0 - p0)
        x_out[mask] = _ppf_marginal(u, margdist, margarg)

    return FieldResult(x_out, STmodel=STmodel)
