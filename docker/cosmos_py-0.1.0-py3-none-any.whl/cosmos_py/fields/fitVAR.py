"""
VAR model fitting for spatio-temporal simulation.

Port of fitVAR.r — Biller-Nelson (2003) algorithm.
References:
  Biller & Nelson (2003), ACM TOMACS 13(3), 211-237
  Papalexiou & Serinaldi (2020), WRR 56(2), e2019WR026331
  Papalexiou, Serinaldi, Porcu (2021), WRR 57, e2020WR029466
"""
import numpy as np
from scipy.spatial.distance import pdist, squareform, cdist

from cosmos_py.fields.anisotropyT import anisotropy_T2
from cosmos_py.fields.advection import advection_F2
from cosmos_py.fields.stcs import stcs2
from cosmos_py.correlation.acti import actpnts, fitactf, actf


def _nearest_pd(A):
    """Return the nearest symmetric positive definite matrix (eigenvalue clipping)."""
    B = (A + A.T) / 2.0
    eigvals, eigvecs = np.linalg.eigh(B)
    eigvals = np.maximum(eigvals, 1e-10)
    return eigvecs @ np.diag(eigvals) @ eigvecs.T


def _nearest_pd_corr(A, tol=1e-4):
    """Return the nearest correlation PD matrix (diagonal forced to 1)."""
    B = _nearest_pd(A)
    d = np.sqrt(np.diag(B))
    d[d == 0] = 1.0
    return B / np.outer(d, d)


def fit_var(spacepoints, p, margdist, margarg, p0,
            distbounds=(-np.inf, np.inf),
            stcsid="clayton", stcsarg=None,
            scalefactor=1,
            anisotropyid="affine",
            anisotropyarg=None,
            advectionid="uniform",
            advectionarg=None,
            dsid="gauss", dsarg=None):
    """
    Fit VAR(p) model parameters for spatio-temporal simulation.

    Parameters
    ----------
    spacepoints : int or ndarray (d x 2)
        Integer m → square field m×m; matrix → d irregular locations.
    p : int
        VAR order.
    margdist : str
        Target marginal distribution ('gengamma', 'burrXII', 'paretoII', ...).
    margarg : dict
        Parameters for the marginal distribution.
    p0 : float
        Probability of zero (intermittency).
    stcsid : str
        Spatio-temporal correlation structure ID.
    stcsarg : dict
        Arguments for the STCS function.
    scalefactor : float
        Distance between pixel centres for grid fields.
    anisotropyid : str
        Anisotropy transformation ID ('affine', 'swirl', 'wave').
    anisotropyarg : dict
        Arguments for the anisotropy transformation.
    advectionid : str
        Advection field ID ('uniform', 'rotation', ...).
    advectionarg : dict
        Arguments for the advection field.
    dsid : str
        Dependence structure ID ('gauss', 'student', 'bardossy', 'bardossyF').
    dsarg : float or None
        Argument for the dependence structure (df for student, m for bardossy).

    Returns
    -------
    dict with keys: alpha, res_cov, mm, p, margdist, margarg, p0, stcs,
                    s_lags, t_lags, grid_lags, distbounds, dsid, dsarg.
    """
    if stcsarg is None:
        stcsarg = {}
    if anisotropyarg is None:
        anisotropyarg = {"phi1": 1, "phi2": 1, "phi12": 0, "theta": 0}
    if advectionarg is None:
        advectionarg = {"u": 0, "v": 0}

    # ── Build coordinate grid ────────────────────────────────────────────────
    if isinstance(spacepoints, (int, np.integer)):
        mm = int(spacepoints) ** 2
        d = np.linspace(0, int(spacepoints) - 1, int(spacepoints)) * scalefactor
        xx, yy = np.meshgrid(d, d)
        dd0 = np.column_stack([xx.ravel(), yy.ravel()])
    elif isinstance(spacepoints, (np.ndarray, list)):
        dd0 = np.asarray(spacepoints, dtype=float)
        mm = dd0.shape[0]
    else:
        raise ValueError("spacepoints must be an int or a (d x 2) array")

    # ── Apply anisotropy and advection to get transformed coords ─────────────
    aniso_args = dict(anisotropyarg)
    aniso_args["spacepoints"] = dd0
    dd = anisotropy_T2(anisotropyid, aniso_args)

    adv_args = dict(advectionarg)
    adv_args["spacepoints"] = dd0
    uv = advection_F2(advectionid, adv_args)   # (mm x 2) array

    dis = squareform(pdist(dd))  # (mm x mm) pairwise distance matrix

    # ── ACTF calibration ─────────────────────────────────────────────────────
    if dsid in ("gauss", "student"):
        pnts = actpnts(margdist=margdist, margarg=margarg, p0=p0,
                       distbounds=distbounds)
    else:
        raise NotImplementedError(f"dsid='{dsid}' not yet supported in fit_var")

    actfpara = fitactf(pnts)
    b = actfpara["actfcoef"]["b"]
    c = actfpara["actfcoef"]["c"]

    # ── Build sigma_i[:,:,k] for k = 0,...,p  (Yule-Walker covariances) ─────
    sigma_i = np.zeros((mm, mm, p + 1))
    for lag in range(p + 1):
        stcsarg1 = dict(stcsarg)
        stcsarg1["t"] = lag

        # Shift coordinates by advection at this time lag
        shifted = dd0 + uv * lag
        aniso1 = dict(anisotropyarg)
        aniso1["spacepoints"] = shifted
        dd1 = anisotropy_T2(anisotropyid, aniso1)

        stcsarg1["s"] = cdist(dd, dd1)
        raw_stcs = stcs2(stcsid, stcsarg1)
        sigma_i[:, :, lag] = actf(np.asarray(raw_stcs, dtype=float), b, c)

    # ── Block Yule-Walker equations for VAR coefficients ─────────────────────
    # sigma_Z is the (p*mm) x (p*mm) block covariance of past p observations
    # sigma is the (mm) x (p*mm) cross-covariance of current vs past
    sigma_Z = np.zeros((p * mm, p * mm))
    sigma   = np.zeros((mm, p * mm))
    for i in range(1, p + 1):
        for j in range(1, p + 1):
            ri = slice((i - 1) * mm, i * mm)
            rj = slice((j - 1) * mm, j * mm)
            if j >= i:
                sigma_Z[ri, rj] = sigma_i[:, :, j - i]
            else:
                sigma_Z[ri, rj] = sigma_i[:, :, i - j].T
        sigma[:, (i - 1) * mm: i * mm] = sigma_i[:, :, i]

    # alpha = sigma @ inv(sigma_Z)  (mm x p*mm)
    alpha = np.linalg.solve(sigma_Z, sigma.T).T

    # ── Residual covariance ───────────────────────────────────────────────────
    sums = np.zeros((mm, mm))
    for i in range(1, p + 1):
        sums += alpha[:, (i - 1) * mm: i * mm] @ sigma_i[:, :, i].T
    sigma_u = _nearest_pd(sigma_i[:, :, 0] - sums)

    # ── Diagnostic STCS output (201 time lags x mm spatial distances) ────────
    d_lags = np.linspace(0, dis.max(), mm) if mm > 1 else np.array([0.0])
    t_lags = np.arange(201)
    uu, dd_grid = np.meshgrid(t_lags, d_lags, indexing="ij")  # (201, mm)
    stcsarg_diag = {k: v for k, v in stcsarg.items() if k not in ("t", "s")}
    stcsarg_diag["t"] = uu.ravel()
    stcsarg_diag["s"] = dd_grid.ravel()
    fout = np.asarray(stcs2(stcsid, stcsarg_diag), dtype=float).reshape(201, mm)

    return {
        "alpha":      alpha,
        "res_cov":    sigma_u,
        "spacepoints": spacepoints,
        "mm":          mm,
        "p":           p,
        "margdist":    margdist,
        "margarg":     margarg,
        "p0":          p0,
        "stcs":        fout,
        "s_lags":      d_lags,
        "t_lags":      t_lags,
        "grid_lags":   dis,
        "distbounds":  distbounds,
        "dsid":        dsid,
        "dsarg":       dsarg,
    }
