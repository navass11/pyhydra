"""
checkRF — numerical and visual check of generated random fields.

Port of checkRF.r — compares sample statistics with theoretical expectations.
"""
import numpy as np
import pandas as pd

from cosmos_py.utils.moments import populationstat, sample_moments


def check_rf(RF, lags=30, nfields=49, method="stat"):
    """
    Compare sample statistics of a random field with theoretical expectations.

    Parameters
    ----------
    RF : FieldResult or ndarray, shape (n, mm)
        Output of generate_rf() or generate_rf_fast().
        Must carry a .STmodel attribute.
    lags : int
        Number of lags for empirical ACF (method='statplot').
    nfields : int
        Number of spatial locations to include in the report.
    method : str
        'stat' returns a DataFrame of basic statistics.

    Returns
    -------
    pd.DataFrame (for method='stat')
        Rows: 'expected' + one per sample location.
        Columns: mean, sd, skew, p0.
    """
    STmodel = getattr(RF, "STmodel", None)
    if STmodel is None:
        raise ValueError(
            "RF must carry a .STmodel attribute. "
            "Use generate_rf() or generate_rf_fast() to produce it."
        )

    margdist   = STmodel["margdist"]
    margarg    = STmodel["margarg"]
    p0         = STmodel["p0"]
    distbounds = STmodel.get("distbounds", None)

    RF = np.asarray(RF)   # (n, mm)
    mm = RF.shape[1]
    npoints = min(nfields, mm)

    if method == "stat":
        exp_mean = populationstat("mean", margdist, margarg, p0=p0,
                                  distbounds=distbounds)
        exp_sd   = populationstat("sd",   margdist, margarg, p0=p0,
                                  distbounds=distbounds)
        exp_skew = populationstat("skew", margdist, margarg, p0=p0,
                                  distbounds=distbounds)

        rows = [{"mean": round(exp_mean, 4),
                 "sd":   round(exp_sd,   4),
                 "skew": round(exp_skew, 4),
                 "p0":   round(float(p0), 4)}]

        for j in range(npoints):
            col = RF[:, j]
            sm  = sample_moments(col, raw=False, central=False, coef=True)
            rows.append({
                "mean": round(float(np.mean(col)), 4),
                "sd":   round(float(np.std(col, ddof=1)), 4),
                "skew": round(float(sm["coefficients"]["cs"]), 4),
                "p0":   round(float(np.mean(col == 0)), 4),
            })

        index = ["expected"] + [f"sample location {j + 1}" for j in range(npoints)]
        return pd.DataFrame(rows, index=index)

    raise NotImplementedError(f"method='{method}' is not yet implemented")
