"""
checkTS.py

Compares sample statistics of generated time series against theoretical
expected values, replicating R's checkTS().
"""
import numpy as np
import pandas as pd

from cosmos_py.utils.moments import populationstat, sample_moments


def checkTS(TS, distbounds=None):
    """
    Compare sample statistics of generated time series against theoretical
    expectations derived from the fitted model attributes.

    Parameters
    ----------
    TS : list of CosmosTS (or list of array-like)
        Output of generate_ts(). Each element must carry CoSMoS metadata
        attributes (margdist, margarg, acsvalue, p0).
    distbounds : tuple or None
        Integration bounds passed to moments() for numerical integration.

    Returns
    -------
    pd.DataFrame with one ``"expected"`` row and one row per simulated series,
    and columns: ``mean``, ``sd``, ``skew``, ``p0``, ``acf_t1``,
    ``acf_t2``, ``acf_t3``.
    """
    if not isinstance(TS, (list, tuple)):
        TS = [TS]

    first = TS[0]
    margdist = getattr(first, "margdist", None)
    margarg  = getattr(first, "margarg",  None)
    p0       = getattr(first, "p0",       0.0)
    acsvalue = getattr(first, "acsvalue", None)

    if margdist is None or margarg is None:
        raise ValueError(
            "Time series must carry CoSMoS metadata attributes. "
            "Generate via generate_ts() to attach them."
        )

    # ── Theoretical expected row ────────────────────────────────────────────
    def _pop(stat):
        return populationstat(stat, margdist, margarg, p0=p0,
                              distbounds=distbounds)

    expected = {
        "mean":   round(_pop("mean"), 4),
        "sd":     round(_pop("sd"),   4),
        "skew":   round(_pop("skew"), 4),
        "p0":     round(float(p0),    4),
        "acf_t1": round(float(acsvalue[1]) if acsvalue is not None and len(acsvalue) > 1 else np.nan, 4),
        "acf_t2": round(float(acsvalue[2]) if acsvalue is not None and len(acsvalue) > 2 else np.nan, 4),
        "acf_t3": round(float(acsvalue[3]) if acsvalue is not None and len(acsvalue) > 3 else np.nan, 4),
    }

    # ── Sample rows ─────────────────────────────────────────────────────────
    rows = [expected]
    for s in TS:
        arr = np.asarray(s, dtype=float)
        sm = sample_moments(arr, raw=False, central=False, coef=True)
        # Full ACF via normalized autocorrelation
        c = arr - arr.mean()
        acf_full = np.correlate(c, c, mode="full")
        acf_vals = acf_full[len(arr) - 1:] / acf_full[len(arr) - 1]

        rows.append({
            "mean":   round(float(np.mean(arr)), 4),
            "sd":     round(float(np.std(arr, ddof=1)), 4),
            "skew":   round(float(sm["coefficients"]["cs"]), 4),
            "p0":     round(float(np.mean(arr == 0)), 4),
            "acf_t1": round(float(acf_vals[1]) if len(acf_vals) > 1 else np.nan, 4),
            "acf_t2": round(float(acf_vals[2]) if len(acf_vals) > 2 else np.nan, 4),
            "acf_t3": round(float(acf_vals[3]) if len(acf_vals) > 3 else np.nan, 4),
        })

    index = ["expected"] + [f"simulation{i+1}" for i in range(len(TS))]
    return pd.DataFrame(rows, index=index)
