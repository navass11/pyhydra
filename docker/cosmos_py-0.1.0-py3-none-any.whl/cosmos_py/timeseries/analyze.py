import pandas as pd
import numpy as np
from cosmos_py.correlation.fitACS import fit_acs, get_acs_args
from cosmos_py.utils.fitDist import fit_dist, get_dist_args
from cosmos_py.timeseries.seasonal_acf import seasonal_acf
from cosmos_py.timeseries.seasonal_ar import seasonal_ar
from cosmos_py.correlation.acti import actpnts, fitactf, actf
from cosmos_py.distributions.ggamma import pggamma
from cosmos_py.correlation.acs import get_acs
from scipy.interpolate import interp1d

from scipy.stats import norm as normal
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

def _ppf(dist, params_dict, u):
    """Quantile function dispatcher for all supported distributions."""
    if dist == 'gengamma':
        from cosmos_py.distributions.ggamma import qggamma
        return qggamma(u, **params_dict)
    if dist == 'paretoII':
        from cosmos_py.distributions.paretoII import qparetoII
        return qparetoII(u, **params_dict)
    if dist == 'burrXII':
        from cosmos_py.distributions.burrXII import qburrXII
        return qburrXII(u, **params_dict)
    if dist == 'burrIII':
        from cosmos_py.distributions.burrIII import qburrIII
        return qburrIII(u, **params_dict)
    if dist == 'gev':
        from cosmos_py.distributions.gev import qgev
        return qgev(u, **params_dict)
    if dist == 'lnorm':
        import scipy.stats as _st
        import numpy as np
        return _st.lognorm.ppf(u, s=params_dict["sdlog"], scale=np.exp(params_dict["meanlog"]))
    raise ValueError(f"Unknown distribution: {dist}")


def analyzeTS(TS, season='month', dist='gengamma', acs_id='weibull',
              norm_type='N1', n_points=30, lag_max=30, opts=None):
    if opts is None:
        opts = {}

    # Ajuste de autocorrelación empírica (incluye ceros)
    ea = seasonal_acf(TS, season=season, lag_max=lag_max)
    afits = [fit_acs(x, acs_id=acs_id) for x in ea.values()]

    # Agrupación estacional (completa y no-cero)
    if season == 'month':
        grouped = TS.groupby(TS['date'].dt.month, sort=True)
        keys = range(1, 13)  # enero a diciembre
    else:
        grouped = TS.groupby(TS['date'].dt.isocalendar().week, sort=True)
        keys = sorted(grouped.groups.keys())  # semanas presentes en los datos

    # Extraer grupos en orden
    data_full = [grouped.get_group(k).copy() for k in keys]
    data_nz = [df[df['value'] > 0].copy() for df in data_full]

    # Ajuste de distribución a valores > 0
    dfits = [fit_dist(df['value'], dist, norm_type=norm_type,
                      n_points=n_points, opts=opts)
             for df in data_nz]

    return {
        'data': (data_full, data_nz),
        'dfits': dfits,
        'afits': afits,
        'season': season,
        'dist': dist,
        'acsID': acs_id,
        'date': TS['date']
    }

def reportTS(aTS, method='stat'):
    from scipy.stats import skew
    from cosmos_py.utils.lmom import l_moments
    dist = aTS['dist']
    acs_id = aTS['acsID']
    season = aTS['season']
    dfits = aTS['dfits']
    afits = aTS['afits']
    data_full, data_nz = aTS['data']

    season_names = [f"{season}_{i+1}" for i in range(len(data_nz))]
    
    if method == 'dist':
        fig, axs = plt.subplots(nrows=4, ncols=3, figsize=(18, 12))
        axs = axs.flatten()

        for i, fit in enumerate(dfits):
            edf = fit['edf']
            dist_name = fit['dist']
            params_dict = fit['params_dict']
            data = fit['data']
            obj_val = fit['objective']

            # Crear ECDF interpolada desde los puntos
            x_vals = np.sort(data)
            ecdf_func = interp1d(edf['x'], edf['p'], kind='previous', bounds_error=False, fill_value=(0, 1))
            y_vals = ecdf_func(x_vals)

            # Generar curva teórica
            x_fit = np.linspace(min(data), max(data), 1000)
            from cosmos_py.utils.fitDist import _cdf as _fdist_cdf
            y_fit = _fdist_cdf(dist_name, params_dict, x_fit)

            ax = axs[i]
            ax.plot(x_fit, np.log(1 - y_fit), label='Fitted', color='grey', lw=1)
            ax.scatter(x_vals, np.log(1 - y_vals), color='royalblue', alpha=0.5, label='Empirical', s=10)
            ax.set_title(f"{season}_{i+1}\nError = {obj_val:.5f}")
            ax.set_xlabel('Nonzero values')
            ax.set_ylabel('log(1 - p)')
            ax.grid(True, which='both', linestyle='--', linewidth=0.5)

        handles, labels = axs[0].get_legend_handles_labels()
        fig.legend(handles, labels, loc='lower center', ncol=2)
        plt.suptitle("Probability distribution fit", fontsize=16)
        plt.tight_layout(rect=[0, 0.05, 1, 0.95])
        plt.show()

    elif method == 'acs':
        fig, axs = plt.subplots(nrows=4, ncols=3, figsize=(18, 12))
        axs = axs.flatten()

        for i, afit in enumerate(afits):
            if afit is None or 'e_acs' not in afit or 'params' not in afit:
                continue

            lags = afit['lags']
            e_acs = afit['e_acs']
            acs_id = afit['acs_id']
            params = afit['params']
            try:
                theo_acs = get_acs(acs_id, lags, **params)
            except Exception:
                theo_acs = np.full_like(e_acs, np.nan)

            ax = axs[i]
            ax.plot(lags, theo_acs, color='gray', lw=2, label='Fitted')
            ax.scatter(lags, e_acs, color='royalblue', alpha=0.6, label='Empirical')
            ax.set_title(f"{season}_{i+1}")
            ax.set_xlabel('Lag')
            ax.set_ylabel('Autocorrelation')
            ax.grid(True, linestyle='--', linewidth=0.5)

        handles, labels = axs[0].get_legend_handles_labels()
        fig.legend(handles, labels, loc='lower center', ncol=2)
        plt.suptitle("Autocorrelation Structure Fit", fontsize=16)
        plt.tight_layout(rect=[0, 0.05, 1, 0.95])
        plt.show()
    
    elif method == 'stat':
        # 1. Dist params
        dp = pd.DataFrame([d['params_dict'] for d in dfits], index=season_names)
        dp.insert(0, 'dist', dist)

        # 2. Error
        err = [d.get('objective', np.nan) for d in dfits]
        dp['error'] = err

        # 3. ACS params
        ap = pd.DataFrame([a['params'] for a in afits], index=season_names)
        ap.insert(0, 'acsID', acs_id)

        # 4. Estadísticos + Momentos L
        stats = []
        for df_full,df_nz in zip(data_full,data_nz):
            v = df_nz['value'].dropna()
            mean = v.mean()
            std = v.std()
            centered = (v - mean) / std if std > 0 else np.zeros_like(v)
            l_stats = l_moments(v.values, r=4)
            l_var  = l_stats['L1'] / l_stats['L2'] if l_stats['L2'] != 0 else np.nan
            l_skew = l_stats['T3']
            l_kurt = l_stats['T4']
            s = {
                'mean': mean,
                'sd': std,
                'min': v.min(),
                'q.5%': v.quantile(0.05),
                'q.25%': v.quantile(0.25),
                'q.50%': v.quantile(0.50),
                'q.75%': v.quantile(0.75),
                'q.95%': v.quantile(0.95),
                'max': v.max(),
                'skew.cs': skew(v, bias=False),
                'l.var': l_var,
                'l.skew': l_skew,
                'l.kurt': l_kurt
            }
            stats.append(s)
        stats_df = pd.DataFrame(stats, index=season_names)

        # 5. Proporción de ceros
        p0 = [1 - len(data_nz[i]) / len(data_full[i]) for i in range(len(data_nz))]
        stats_df['p0'] = p0

        # 6. Autocorrelación lags 2–5
        for lag in range(1, 5):
            stats_df[f'acs.l.{lag+1}'] = [a['e_acs'][lag] if len(a['e_acs']) > lag else np.nan for a in afits]

        # Ensamblar todo
        out = pd.concat([dp, ap, stats_df], axis=1)
        out.index.name = 'season'

        return out

    else:
        raise ValueError(f"Unknown method: {method}")

def simulateTS(aTS, from_date=None, to_date=None):
    dist = aTS['dist']
    season = aTS['season']
    date = pd.to_datetime(aTS['date'])

    data_full, _ = aTS['data']
    dfits = aTS['dfits']
    afits = aTS['afits']

    report = reportTS(aTS, method='stat')
    p0_list = report['p0'].values

    # Infer the season labels that correspond to data_full[0], data_full[1], ...
    if season == 'month':
        season_values = list(range(1, len(data_full) + 1))
    else:
        season_values = [
            int(df['date'].dt.isocalendar().week.iloc[0]) for df in data_full
        ]

    # Build Gaussian ACS dict keyed as "{season}_{value}"
    ACS_dict = {}
    for i, s in enumerate(season_values):
        dist_args = dfits[i]['params_dict']
        p0 = p0_list[i]
        act_pts = actpnts(margdist=dist, margarg=dist_args, p0=p0)
        fp = fitactf(act_pts)

        lag = afits[i]['lags']
        acs_id = afits[i]['acs_id']
        acs_params = afits[i]['params']
        theo_acs = get_acs(acs_id, lag, **acs_params)

        # Convert target ACS to Gaussian ACS; force lag-0 = 1.0
        gauss_acs = actf(theo_acs, fp['actfcoef']['b'], fp['actfcoef']['c'])
        gauss_acs = np.concatenate([[1.0], gauss_acs[1:]])

        ACS_dict[f"{season}_{s}"] = gauss_acs

    if from_date is None:
        from_date = date.min()
    if to_date is None:
        to_date = date.max()

    time_index = pd.date_range(start=from_date, end=to_date, freq='D')
    gauss_df = seasonal_ar(time_index, ACS_dict, season=season)

    # Vectorised quantile transform, one season at a time
    result = gauss_df[['date', 'season']].copy()
    result['value'] = np.nan

    for s_idx, s in enumerate(season_values):
        mask = gauss_df['season'] == s
        p0 = p0_list[s_idx]

        g_vals = gauss_df.loc[mask, 'gauss'].values
        raw = (normal.cdf(g_vals) - p0) / (1.0 - p0)
        zero_mask = raw <= 0.0
        uval = np.clip(raw, 1e-10, 1.0 - 1e-10)

        dparams = dfits[s_idx]['params_dict']
        val = _ppf(dist, dparams, uval)

        val[zero_mask] = 0.0
        result.loc[mask, 'value'] = val

    return result[['date', 'value']].sort_values('date').reset_index(drop=True)