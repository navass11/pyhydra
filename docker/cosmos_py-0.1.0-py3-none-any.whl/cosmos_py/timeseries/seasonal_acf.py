import pandas as pd
import numpy as np


def seasonal_acf(TS, season='month', lag_max=50):
    """
    Calculate seasonal ACF.

    Parameters:
        TS (pd.DataFrame): Time series with columns 'date' and 'value'.
        season (str): Season type. Currently supports 'month' or 'week'.
        lag_max (int): Maximum lag to compute.

    Returns:
        dict: Dictionary with seasonal ACF vectors.
    """
    TS = TS.copy()
    TS['lag0'] = np.arange(len(TS))

    if season == 'month':
        TS['season'] = TS['date'].dt.month
    elif season == 'week':
        TS['season'] = TS['date'].dt.isocalendar().week
    else:
        raise ValueError(f"Unsupported season: {season}")

    for i in range(1, lag_max + 1):
        TS[f'lag{i}'] = TS['lag0'] - i

    results = {}
    for j in TS['season'].unique():
        sub = TS[TS['season'] == j]
        index = sub[[f'lag{i}' for i in range(1, lag_max + 1)] + ['lag0']].reset_index(drop=True)

        acf_vals = []
        for i in range(1, lag_max + 1):
            valid_rows = index[index[f'lag{i}'] > 0]
            if valid_rows.empty:
                acf_vals.append(np.nan)
                continue

            xi = valid_rows['lag0'].values
            yi = valid_rows[f'lag{i}'].values

            x = TS.loc[xi, 'value'].values
            y = TS.loc[yi, 'value'].values

            corr = np.corrcoef(x, y)[0, 1] if len(x) > 1 else np.nan
            acf_vals.append(corr)

        results[f'{season}_{j}'] = [1.0] + acf_vals  # add lag 0 correlation

    return results
