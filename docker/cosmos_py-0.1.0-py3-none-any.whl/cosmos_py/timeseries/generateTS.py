"""
generate_ts.py

Funciones para generar series temporales sintéticas con estructura de autocorrelación y distribución marginal deseadas.
Equivalente a la función `generateTS` del paquete CoSMoS en R.
"""
import numpy as np
from scipy.stats import norm
from scipy.integrate import quad
from cosmos_py.correlation.acti import actpnts, fitactf
from cosmos_py.correlation.arp import ARp, regenerateTS


def generate_ts(n, margdist, margarg, p=None, p0=0, TSn=1, distbounds=None, acsvalue=None):
    """
    Genera series temporales con propiedades deseadas de marginal y autocorrelación.

    Parameters:
        n: longitud de la serie temporal
        margdist: nombre de la distribución marginal (str)
        margarg: argumentos de la distribución marginal (dict)
        p: orden del modelo autorregresivo (opcional)
        p0: probabilidad de ceros (opcional)
        TSn: número de series a generar (default 1)
        distbounds: límites de integración para momentos (default (-inf, inf))
        acsvalue: estructura de autocorrelación o valores (opcional)

    Returns:
        Lista de arrays NumPy con series generadas.
    """
    if acsvalue is None:
        raise ValueError(
            "acsvalue must be provided. Supply an array of target autocorrelations "
            "starting at lag 0 (e.g. from cosmos_py.correlation.acs.get_acs)."
        )

    acsvalue = np.asarray(acsvalue, dtype=float)

    kw = {} if distbounds is None else {'distbounds': distbounds}
    points = actpnts(margdist=margdist, margarg=margarg, p0=p0, **kw)
    params = fitactf(points)

    series_list = []
    for _ in range(TSn):
        series = ARp(
            margdist=margdist,
            margarg=margarg,
            n=n,
            p=p,
            p0=p0,
            actfpara=params,
            acsvalue=acsvalue,
        )
        series_list.append(series)

    return series_list


