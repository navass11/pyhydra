import numpy as np
import pandas as pd


def YW(ACS):
    """Solve Yule-Walker equations for a given autocorrelation vector."""
    p = len(ACS) - 1
    if p == 0:
        return np.array([])
    P = np.empty((p, p))
    for i in range(p):
        P[i, i:] = ACS[:p - i]
        P[i, :i] = ACS[i:0:-1]
    rho = np.array(ACS[1:p + 1]).reshape(p, 1)
    return np.linalg.solve(P, rho).flatten()


def AR1(n, alpha, mean=0, sd=1):
    """Generate an AR(1) series of length n."""
    emean = (1 - alpha) * mean
    esd = np.sqrt(max(1 - alpha ** 2, 1e-10)) * sd
    val = [np.random.normal(mean, sd)]
    gn = np.random.normal(emean, esd, n)
    for i in range(1, n):
        val.append(alpha * val[i - 1] + gn[i])
    return np.array(val)


def seasonal_ar(dates, ACS, season="month"):
    """
    Simulate a seasonal Gaussian AR process in chronological order.

    Parameters
    ----------
    dates : array-like of datetime
        Target dates for the output series.
    ACS : dict
        Gaussian autocorrelation arrays per season, keyed as
        ``"{season}_{value}"`` (e.g. ``"month_1"``).  Each array starts
        with 1.0 at lag 0.
    season : str
        ``"month"`` or ``"week"``.

    Returns
    -------
    pd.DataFrame with columns ``date``, ``gauss``, ``season``.
    """
    alpha = {k: YW(v) for k, v in ACS.items()}

    esd = {}
    for k, a in alpha.items():
        rho_lags = np.asarray(ACS[k])[1:len(a) + 1]
        var = max(1.0 - np.dot(a, rho_lags), 1e-10)
        esd[k] = np.sqrt(var)

    dates = pd.DatetimeIndex(dates)
    n = len(dates)

    if season == "month":
        season_vals = dates.month.to_numpy()
    elif season == "week":
        season_vals = np.array([d.isocalendar()[1] for d in dates])
    else:
        season_vals = getattr(dates, season).to_numpy()

    # Warm-up: initialise history using AR1 with the first season's lag-1 corr
    first_key = next(iter(ACS))
    first_acs = np.asarray(ACS[first_key])
    rho1 = float(first_acs[1]) if len(first_acs) > 1 else 0.0
    p_max = max(len(a) for a in alpha.values()) if alpha else 1
    history = list(AR1(p_max, rho1))

    gauss = np.zeros(n)
    for i in range(n):
        s = int(season_vals[i])
        key = f"{season}_{s}"
        a = alpha[key]
        p = len(a)
        prev = np.asarray(history[-p:]) if p > 0 else np.array([])
        val = (np.dot(a, prev[::-1]) if p > 0 else 0.0) + np.random.normal(0.0, esd[key])
        gauss[i] = val
        history.append(val)

    return pd.DataFrame({"date": dates, "gauss": gauss, "season": season_vals})
