
"""
actf.py

Contiene funciones para ajustar la función de transformación de autocorrelación (ACTF).
"""
import numpy as np
from scipy.optimize import curve_fit


def actf_model(rhoz, a, b):
    return 1 - (1 - rhoz ** (1 / a)) ** b


def fit_actf(rhoz, rhox):
    popt, _ = curve_fit(actf_model, rhoz, rhox, bounds=(0, [10.0, 10.0]))
    return popt  # (a, b)
