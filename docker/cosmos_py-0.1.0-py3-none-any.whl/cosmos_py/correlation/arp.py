"""
arp.py

AR(p) simulation with a target marginal distribution, matching the R ARp().
Returns a numpy-array subclass that carries CoSMoS metadata (margdist, margarg,
acsvalue, p0, ar_coef, noise_sd, gaussian, transformed_acs) so that
regenerateTS() can re-use fitted parameters without re-running actpnts/fitactf.
"""
import numpy as np
from scipy.stats import norm as normal_dist

from cosmos_py.timeseries.seasonal_ar import YW
from cosmos_py.correlation.acti import actf


# ── CosmosTS: numpy array subclass carrying metadata ─────────────────────────

class CosmosTS(np.ndarray):
    """
    Numpy array subclass that carries CoSMoS metadata attributes.
    Behaves exactly like a numpy array for all numerical operations.
    """
    _meta_attrs = (
        "margdist", "margarg", "acsvalue", "p0",
        "ar_coef", "noise_sd", "gaussian", "transformed_acs",
    )

    def __new__(cls, data, **meta):
        obj = np.asarray(data).view(cls)
        for k in cls._meta_attrs:
            setattr(obj, k, meta.get(k, None))
        return obj

    def __array_finalize__(self, obj):
        if obj is None:
            return
        for k in self._meta_attrs:
            setattr(self, k, getattr(obj, k, None))


# ── Quantile transform dispatcher ─────────────────────────────────────────────

def _ppf(dist, distarg, u):
    if dist in ("ggamma", "gengamma"):
        from cosmos_py.distributions.ggamma import qggamma
        return qggamma(u, **distarg)
    if dist == "paretoII":
        from cosmos_py.distributions.paretoII import qparetoII
        return qparetoII(u, **distarg)
    if dist == "burrXII":
        from cosmos_py.distributions.burrXII import qburrXII
        return qburrXII(u, **distarg)
    if dist == "burrIII":
        from cosmos_py.distributions.burrIII import qburrIII
        return qburrIII(u, **distarg)
    if dist == "gev":
        from cosmos_py.distributions.gev import qgev
        return qgev(u, **distarg)
    import scipy.stats as _st
    return getattr(_st, dist)(**distarg).ppf(u)


# ── Core AR(p) function ───────────────────────────────────────────────────────

def ARp(margdist, margarg, n, p=None, p0=0.0, actfpara=None, acsvalue=None):
    """
    Generate a single time series with an AR(p) Gaussian backbone
    transformed to the target marginal distribution.

    Returns a CosmosTS (numpy array subclass) with attributes:
        margdist, margarg, acsvalue, p0, ar_coef, noise_sd,
        gaussian, transformed_acs.
    """
    if actfpara is None or acsvalue is None:
        raise ValueError("Both actfpara and acsvalue must be provided.")

    b = actfpara["actfcoef"]["b"]
    c = actfpara["actfcoef"]["c"]

    acsvalue = np.asarray(acsvalue, dtype=float)

    # Transform marginal ACS to Gaussian ACS via ACTF
    transformed_acs = actf(acsvalue, b, c)
    transformed_acs[0] = 1.0  # enforce lag-0 = 1

    # Determine AR order
    if p is None:
        sig = np.where(transformed_acs > 0.01)[0]
        p = int(min(len(sig) - 1, 1000)) if len(sig) > 1 else 1

    p = min(p, len(transformed_acs) - 1)
    rhoz_p = transformed_acs[: p + 1]

    # Yule-Walker AR coefficients
    ar_coef = YW(rhoz_p)

    # Innovation standard deviation
    noise_sd = float(np.sqrt(max(1.0 - np.dot(ar_coef, rhoz_p[1:]), 1e-10)))

    # Simulate Gaussian AR(p): p burn-in steps
    series = np.zeros(n + p)
    series[:p] = np.random.normal(0, 1, p)
    innovations = np.random.normal(0, noise_sd, n + p)
    ar_rev = ar_coef[::-1]
    for i in range(p, n + p):
        series[i] = np.dot(ar_rev, series[i - p:i]) + innovations[i]

    gaussian = series[p:]

    # Probability-integral transform with intermittency
    raw = (normal_dist.cdf(gaussian) - p0) / (1.0 - p0)
    zero_mask = raw <= 0.0
    u = np.clip(raw, 1e-10, 1.0 - 1e-10)

    values = np.asarray(_ppf(margdist, margarg, u), dtype=float)
    values[zero_mask] = 0.0

    return CosmosTS(
        values,
        margdist=margdist,
        margarg=dict(margarg),
        acsvalue=acsvalue.copy(),
        p0=float(p0),
        ar_coef=ar_coef.copy(),
        noise_sd=noise_sd,
        gaussian=gaussian.copy(),
        transformed_acs=transformed_acs.copy(),
    )


# ── Bulk regeneration ─────────────────────────────────────────────────────────

def regenerateTS(ts, TSn=1):
    """
    Generate additional time series using parameters already fitted by
    generate_ts(), without re-computing the ACTF.

    Parameters
    ----------
    ts : list of CosmosTS
        Output of generate_ts().
    TSn : int
        Number of new series to generate.

    Returns
    -------
    list of CosmosTS
    """
    first = ts[0]
    margdist = first.margdist
    margarg = first.margarg
    n = len(first)
    p = len(first.ar_coef)
    p0 = first.p0
    ar_coef = first.ar_coef
    noise_sd = first.noise_sd
    acsvalue = first.acsvalue
    transformed_acs = first.transformed_acs
    ar_rev = ar_coef[::-1]

    out = []
    for _ in range(TSn):
        # Burn-in 2*p steps, then generate n
        burn = 2 * p
        series = np.zeros(burn + n)
        series[:p] = np.random.normal(0, 1, p)
        innovations = np.random.normal(0, noise_sd, burn + n)
        for i in range(p, burn + n):
            series[i] = np.dot(ar_rev, series[i - p:i]) + innovations[i]

        gaussian = series[burn:]
        raw = (normal_dist.cdf(gaussian) - p0) / (1.0 - p0)
        zero_mask = raw <= 0.0
        u = np.clip(raw, 1e-10, 1.0 - 1e-10)

        values = np.asarray(_ppf(margdist, margarg, u), dtype=float)
        values[zero_mask] = 0.0

        out.append(CosmosTS(
            values,
            margdist=margdist,
            margarg=dict(margarg),
            acsvalue=acsvalue.copy(),
            p0=p0,
            ar_coef=ar_coef.copy(),
            noise_sd=noise_sd,
            gaussian=gaussian.copy(),
            transformed_acs=transformed_acs.copy(),
        ))
    return out
