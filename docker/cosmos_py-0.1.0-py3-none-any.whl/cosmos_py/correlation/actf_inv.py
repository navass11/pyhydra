
"""
actf_inv.py

Contiene la inversa de la función ACTF, útil para transformar correlaciones objetivo en correlaciones gaussianas.
"""
import numpy as np


def actf_inv(rhox, a, b):
    return (1 - (1 - rhox) ** (1 / b)) ** a
