
"""
acs.py

Contiene funciones para estructuras de autocorrelación paramétricas equivalentes al método 'acs' del paquete CoSMoS en R.
"""

import numpy as np


def acfburrXII(t, scale, shape1, shape2):
    if (shape1 <= 0) or (shape2 <= 0):
        return float('nan')
    else:
        return (1 + shape2 * (t / scale) ** shape1) ** (-1 / (shape1 * shape2))



def acfparetoII(t, scale, shape):
    """
    Autocorrelation function for the Pareto II distribution.
    """
    t = np.asarray(t)
    if scale <= 0 or shape <= 0:
        return np.full_like(t, np.nan, dtype=np.float64)
    return (1 + (shape * t) / scale) ** (-1 / shape)


def acffgn(t, H):
    """
    Autocorrelation function for fractional Gaussian noise.
    """
    t = np.asarray(t)
    return (
        (np.abs(t - 1) ** (2 * H) -
         2 * np.abs(t) ** (2 * H) +
         np.abs(t + 1) ** (2 * H)) / 2
    )


def acfweibull(t, scale, shape):
    """
    Autocorrelation function for the Weibull distribution.
    """
    t = np.asarray(t, dtype=float)
    if scale <= 0 or shape <= 0:
        return np.full_like(t, np.nan, dtype=float)
    with np.errstate(invalid='ignore', over='ignore'):
        return np.exp(-(t / scale) ** shape)

def get_acs(id, t, **kwargs):
    """Dispatcher para seleccionar la estructura de autocorrelación deseada"""
    if id == "fgn":
        return acffgn(t, **kwargs)
    elif id == "burrXII":
        return acfburrXII(t, **kwargs)
    elif id == "weibull":
        return acfweibull(t, **kwargs)
    elif id == "paretoII":
        return acfparetoII(t, **kwargs)
    else:
        raise ValueError(f"Estructura de autocorrelación desconocida: {id}")
