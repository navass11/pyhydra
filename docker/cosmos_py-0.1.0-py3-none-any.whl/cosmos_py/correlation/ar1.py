
"""
ar1.py

Generación de series temporales con estructura AR(1)
"""
import numpy as np


def generate_ar1(n, rho, sigma=1, mu=0):
    series = np.zeros(n)
    series[0] = np.random.normal(mu, sigma)
    for i in range(1, n):
        series[i] = mu + rho * (series[i - 1] - mu) + np.random.normal(0, sigma)
    return series
