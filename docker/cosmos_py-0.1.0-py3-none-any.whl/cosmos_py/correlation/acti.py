import numpy as np
from scipy.special import erfc, erfcinv
from scipy.integrate import dblquad
from scipy.optimize import least_squares

from cosmos_py.distributions.ggamma import qggamma
from cosmos_py.utils import moments


def _to_dict(params):
    if isinstance(params, dict):
        return params
    elif isinstance(params, (list, tuple, np.ndarray)):
        return {'scale': params[0], 'shape1': params[1], 'shape2': params[2]}
    else:
        raise TypeError("params must be a dict or array-like.")


def _quantile(dist, distarg, p):
    p = float(np.clip(p, 1e-10, 1 - 1e-10))
    if isinstance(dist, str):
        if dist in ("ggamma", "gengamma"):
            return float(qggamma(p, **_to_dict(distarg)))
        if dist == "paretoII":
            from cosmos_py.distributions.paretoII import qparetoII
            return float(qparetoII(p, **distarg))
        if dist == "burrXII":
            from cosmos_py.distributions.burrXII import qburrXII
            return float(qburrXII(p, **distarg))
        if dist == "burrIII":
            from cosmos_py.distributions.burrIII import qburrIII
            return float(qburrIII(p, **distarg))
        if dist == "gev":
            from cosmos_py.distributions.gev import qgev
            return float(qgev(p, **distarg))
        if dist == "lnorm":
            import scipy.stats as _st
            return float(_st.lognorm.ppf(p, s=distarg["sdlog"], scale=np.exp(distarg["meanlog"])))
        import scipy.stats as _st
        dist_obj = getattr(_st, dist, None)
        if dist_obj is None:
            raise NotImplementedError(f"Distribution '{dist}' not found in scipy.stats.")
        return float(dist_obj.ppf(p, **distarg))
    elif hasattr(dist, "ppf"):
        return float(dist.ppf(p, **distarg))
    else:
        raise TypeError("dist must be a string or a scipy.stats distribution object.")


def acti(x, y, dist, distarg, rhoz, p0):
    """ACTI — autocorrelation transformation integral kernel."""
    def qfunc(z):
        p = (erfc(-z / np.sqrt(2)) / 2.0 - p0) / (1.0 - p0)
        return _quantile(dist, distarg, p)

    term1 = qfunc(x)
    term2 = qfunc(y)
    exponent = (x ** 2 + y ** 2 - 2.0 * x * y * rhoz) / (2.0 * (1.0 - rhoz ** 2))
    return term1 * term2 * np.exp(-exponent) / (2.0 * np.pi * np.sqrt(1.0 - rhoz ** 2))


def actpnts(margdist, margarg, p0=0.0, distbounds=None):
    """
    AutoCorrelation Transformed Points — evaluates the (rhox, rhoz) mapping.

    Returns an (10, 2) array where column 0 is rhox and column 1 is rhoz.
    """
    rhoz_vals = np.array([0.1 * i for i in range(1, 10)] + [0.95])
    rhox_vals = []

    lower = -7.5 if p0 == 0 else -np.sqrt(2) * erfcinv(2 * p0)
    upper = 7.5

    if distbounds is None:
        distbounds = (0, np.inf)

    m = moments.compute_moments(margdist, margarg, raw=False, central=True,
                                coef=False, distbounds=distbounds, p0=p0, order=[1, 2])

    mu1, mu2 = m["mu"]["mu1"], m["mu"]["mu2"]

    for rhoz in rhoz_vals:
        integral, _ = dblquad(
            lambda y, x: acti(x, y, margdist, margarg, rhoz, p0),
            lower, upper,
            lambda _: lower, lambda _: upper,
            epsabs=1e-5, epsrel=1e-5
        )
        rhox_vals.append((integral - mu1 ** 2) / mu2)

    return np.column_stack((rhox_vals, rhoz_vals))


def actf(rhox, b, c):
    """
    AutoCorrelation Transformation Function (continuous).

    R formula: ((1 + b*rhox)^(1-c) - 1) / ((1 + b)^(1-c) - 1)
    Special case c=1 (L'Hôpital): log(1 + b*rhox) / log(1 + b)
    """
    rhox = np.asarray(rhox, dtype=float)
    if abs(c - 1.0) < 1e-10:
        return np.log1p(b * rhox) / np.log1p(b)
    denom = (1.0 + b) ** (1.0 - c) - 1.0
    return ((1.0 + b * rhox) ** (1.0 - c) - 1.0) / denom


def actf_inv(rhoz, b, c):
    """
    Inverse of the ACTF.

    R formula: ((rhoz * ((1+b)^(1-c) - 1) + 1)^(1/(1-c)) - 1) / b
    """
    rhoz = np.asarray(rhoz, dtype=float)
    denom_actf = (1.0 + b) ** (1.0 - c) - 1.0
    return ((rhoz * denom_actf + 1.0) ** (1.0 / (1.0 - c)) - 1.0) / b


def actfdiscrete(rhox, b, c):
    """AutoCorrelation Transformation Function for discrete distributions."""
    rhox = np.asarray(rhox, dtype=float)
    return 1.0 - (1.0 - rhox ** b) ** c


def fitactf(actpoints, discrete=False):
    """
    Fit the ACTF to estimated (rhox, rhoz) points using least-squares.

    Starting values and bounds match the R implementation (b=1, c=0; b>0, c≥0).
    """
    rhox = actpoints[:, 0]
    rhoz = actpoints[:, 1]

    if discrete:
        def residuals(params):
            b, c = params
            return actfdiscrete(rhox, b, c) - rhoz
    else:
        def residuals(params):
            b, c = params
            return actf(rhox, b, c) - rhoz

    x0 = np.array([1.0, 0.0])
    bounds = ([1e-3, 0.0], [np.inf, np.inf])

    res = least_squares(residuals, x0, bounds=bounds, max_nfev=50000)
    b, c = res.x

    return {"actfcoef": {"b": float(b), "c": float(c)}, "actfpoints": actpoints}
