# correlation/fit_acs.py

import numpy as np
from scipy.optimize import minimize
import matplotlib.pyplot as plt
from cosmos_py.correlation.acs import get_acs


def get_acs_args(acs_id):
    """Devuelve la lista de argumentos requeridos para cada estructura ACS"""
    if acs_id == 'fgn':
        return ['H']
    elif acs_id == 'burrXII':
        return ['scale', 'shape1', 'shape2']
    elif acs_id == 'weibull':
        return ['scale', 'shape']
    elif acs_id == 'paretoII':
        return ['scale', 'shape']
    else:
        raise ValueError(f"ACS ID desconocido: {acs_id}")


def mse(x, y):
    return np.mean((np.array(x) - np.array(y)) ** 2)


def optim_acs(par, acs_id, e_acs, error='MSE'):
    arg_names = get_acs_args(acs_id)
    param_dict = dict(zip(arg_names, par))
    t = np.arange(len(e_acs))
    theo_acs = get_acs(acs_id, t, **param_dict)

    if error == 'MSE':
        return mse(theo_acs, e_acs)
    else:
        raise ValueError("Solo se soporta 'MSE'")


def fit_acs(e_acs, acs_id, start=None, lag=None):
    e_acs = np.asarray(e_acs)
    if lag is not None:
        e_acs = e_acs[:lag + 1]
    else:
        if np.any(e_acs <= 0.01):
            e_acs = e_acs[:np.where(e_acs <= 0.01)[0][0] + 1]

    arg_names = get_acs_args(acs_id)

    if start is None:
        start = [1.0] * len(arg_names)

    res = minimize(
        optim_acs, start, args=(acs_id, e_acs),
        method='Nelder-Mead',
        options={'maxiter': 10000, 'maxfev': 10000, 'xatol': 1e-6, 'fatol': 1e-6},
    )

    if not res.success and res.fun > 0.1:
        raise RuntimeError(f"Optimización fallida: {res.message}")

    fitted_params = dict(zip(arg_names, res.x))

    return {
        'params': fitted_params,
        'acs_id': acs_id,
        'e_acs': e_acs,
        'lags': np.arange(len(e_acs))
    }


def plot_fit_acs(fit_result):
    e_acs = fit_result['e_acs']
    acs_id = fit_result['acs_id']
    lags = fit_result['lags']
    theo_acs = get_acs(acs_id, lags, **fit_result['params'])

    plt.figure(figsize=(8, 5))
    plt.plot(lags, theo_acs, label='Teórico', color='gray', lw=2)
    plt.scatter(lags, e_acs, label='Empírico', color='red')
    plt.xlabel('Retardo (lag)')
    plt.ylabel('Autocorrelación')
    plt.title(f'Ajuste estructura de autocorrelación: {acs_id}')
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()
