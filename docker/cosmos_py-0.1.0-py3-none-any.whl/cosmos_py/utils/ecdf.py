import numpy as np
import pandas as pd
from typing import Dict

def compute_ecdf(data: np.ndarray) -> Dict[str, np.ndarray]:
    """
    Calcula la ECDF igual que la función ECDF del paquete CoSMoS en R.
    - Usa posiciones de Weibull: rank / (N + 1)
    - Para valores repetidos, se conserva la última aparición (equivalente a mult='last' en data.table)

    Args:
        data: Array de datos de entrada

    Returns:
        Diccionario con:
        - 'x': valores únicos ordenados
        - 'y': probabilidades acumuladas
        - 'values': alias de x
        - 'p': alias de y
    """
    data = np.asarray(data)
    sorted_x = np.sort(data)
    n = len(sorted_x)

    # Ranking tipo 'first', posición de Weibull
    order = np.argsort(np.argsort(sorted_x, kind='stable'))
    ranks = order + 1
    p_vals = ranks / (n + 1)

    df_all = pd.DataFrame({'value': sorted_x, 'p': p_vals})

    # Conservar solo la última p para cada valor único (equivale a mult='last' en R)
    ecdf = df_all.groupby('value', as_index=False).last()

    return {
        'values': ecdf['value'].to_numpy(),
        'p': ecdf['p'].to_numpy(),
        'x': ecdf['value'].to_numpy(),
        'y': ecdf['p'].to_numpy()
    }