
"""
getArg.py

Función utilitaria para extraer argumentos nombrados.
"""
def get_arg(name, default, args):
    return args.get(name, default)
