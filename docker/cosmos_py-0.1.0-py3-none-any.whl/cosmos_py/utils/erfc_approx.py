
"""
erfc_approx.py

Aproximación a la función erfc (complementaria de error).
"""
import numpy as np
from scipy.special import erfc


def erfc_custom(x):
    return erfc(x)
