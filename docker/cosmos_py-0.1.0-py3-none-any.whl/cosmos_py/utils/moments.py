import numpy as np
from scipy.integrate import quad


# ── Analytical moment dispatchers ─────────────────────────────────────────────

_ANALYTICAL_MOMENTS = {
    "gengamma": "cosmos_py.distributions.ggamma.mggamma",
    "paretoII":  "cosmos_py.distributions.paretoII.mparetoII",
    "burrXII":   "cosmos_py.distributions.burrXII.mburrXII",
    "burrIII":   "cosmos_py.distributions.burrIII.mburrIII",
    "gev":       "cosmos_py.distributions.gev.mgev",
}


def _get_moment_fn(dist):
    """Return the analytical moment function for *dist*, or None."""
    path = _ANALYTICAL_MOMENTS.get(dist)
    if path is None:
        return None
    module_path, fn_name = path.rsplit(".", 1)
    import importlib
    mod = importlib.import_module(module_path)
    return getattr(mod, fn_name)


def _get_pdf_fn(dist, distarg):
    """Return a scalar pdf callable for numerical integration."""
    if dist in ("gengamma",):
        from cosmos_py.distributions.ggamma import dggamma
        return lambda x: float(np.squeeze(dggamma(np.asarray([x]), **distarg)))
    if dist == "paretoII":
        from cosmos_py.distributions.paretoII import dparetoII
        return lambda x: float(np.squeeze(dparetoII(np.asarray([x]), **distarg)))
    if dist == "burrXII":
        from cosmos_py.distributions.burrXII import dburrXII
        return lambda x: float(np.squeeze(dburrXII(np.asarray([x]), **distarg)))
    if dist == "burrIII":
        from cosmos_py.distributions.burrIII import dburrIII
        return lambda x: float(np.squeeze(dburrIII(np.asarray([x]), **distarg)))
    if dist == "gev":
        from cosmos_py.distributions.gev import dgev
        return lambda x: float(np.squeeze(dgev(np.asarray([x]), **distarg)))
    if dist == "lnorm":
        import scipy.stats as _st
        s = distarg["sdlog"]
        scale = np.exp(distarg["meanlog"])
        return lambda x: float(_st.lognorm.pdf(x, s=s, scale=scale))
    import scipy.stats as _st
    dist_obj = getattr(_st, dist)
    return lambda x: float(dist_obj.pdf(x, **distarg))


# ── Theoretical moments (numerical or analytical) ─────────────────────────────

def compute_moments(dist, distarg, p0=0, raw=True, central=True, coef=True,
                    distbounds=None, order=None):
    """
    Compute theoretical moments of a distribution, replicating R's moments().

    Uses analytical moment functions (m<dist>) when available, falling back
    to numerical integration otherwise.

    Returns dict with keys ``m`` (raw), ``mu`` (central), ``coefficients``.
    """
    if order is None:
        order = [1, 2, 3, 4]
    if (central or coef) and max(order) < 4:
        order = [1, 2, 3, 4]

    if distbounds is None:
        distbounds = (0, np.inf)

    if isinstance(distarg, (list, tuple, np.ndarray)):
        distarg = dict(zip(["scale", "shape1", "shape2"], distarg))

    m_fn = _get_moment_fn(dist)
    m_raw = {}

    if m_fn is not None:
        for i in order:
            val = m_fn(r=i, **distarg)
            m_raw[f"m{i}"] = float(val) if np.isfinite(val) else float("nan")
    else:
        pdf_fn = _get_pdf_fn(dist, distarg)
        for i in order:
            val, _ = quad(lambda x: x ** i * pdf_fn(x),
                          distbounds[0], distbounds[1],
                          epsabs=1e-6, limit=200)
            m_raw[f"m{i}"] = val

    # Apply intermittency weight
    m = {k: (1 - p0) * v for k, v in m_raw.items()}

    out = {}
    if raw:
        out["m"] = m

    if central or coef:
        mu1 = m["m1"]
        mu2 = m["m2"] - mu1 ** 2
        mu3 = 2 * mu1 ** 3 - 3 * m["m2"] * mu1 + m["m3"]
        mu4 = -3 * mu1 ** 4 + 6 * m["m2"] * mu1 ** 2 - 4 * m["m3"] * mu1 + m["m4"]
        mu_dict = {"mu1": mu1, "mu2": mu2, "mu3": mu3, "mu4": mu4}
        if central:
            out["mu"] = mu_dict

    if coef:
        cv = float(np.sqrt(mu2) / mu1) if mu1 != 0 else float("nan")
        cs = float(mu3 / mu2 ** 1.5)  if mu2 > 0  else float("nan")
        ck = float(mu4 / mu2 ** 2)    if mu2 > 0  else float("nan")
        out["coefficients"] = {"cv": cv, "cs": cs, "ck": ck}

    return out


# ── Sample moments ────────────────────────────────────────────────────────────

def sample_moments(x, na_rm=False, raw=True, central=True, coef=True,
                   order=None):
    """
    Compute sample moments, replicating R's sample.moments().

    Returns dict with keys ``m`` (raw), ``mu`` (central), ``coefficients``
    (CV, skewness, kurtosis).
    """
    if order is None:
        order = [1, 2, 3, 4]
    if (central or coef) and max(order) < 4:
        order = [1, 2, 3, 4]

    x = np.asarray(x, dtype=float)
    if na_rm:
        x = x[np.isfinite(x)]
    n = len(x)
    xbar = np.mean(x)

    out = {}

    if raw:
        m = {f"m{i}": float(np.sum(x ** i) / n) for i in order}
        out["m"] = m

    if central or coef:
        mu = {f"mu{i}": float(np.sum((x - xbar) ** i) / n) for i in order}
        if central:
            out["mu"] = mu

    if coef:
        mu2 = mu["mu2"]
        mu3 = mu["mu3"]
        mu1_raw = float(np.sum(x) / n)
        cv = float(np.sqrt(mu2) / mu1_raw) if mu1_raw != 0 else float("nan")
        cs = float(mu3 / mu2 ** 1.5) if mu2 > 0 else float("nan")
        ck = float(mu["mu4"] / mu2 ** 2) if mu2 > 0 else float("nan")
        out["coefficients"] = {"cv": cv, "cs": cs, "ck": ck}

    return out


# ── Population statistics ─────────────────────────────────────────────────────

def populationstat(stat, dist, distarg, p0=0, distbounds=None):
    """
    Compute a single theoretical statistic, replicating R's populationstat().

    Parameters
    ----------
    stat : str
        One of ``"mean"``, ``"sd"``, ``"var"``, ``"cvar"``, ``"skew"``,
        ``"kurt"``.
    dist : str
        Distribution name.
    distarg : dict
        Distribution parameters.
    p0 : float
        Probability of zeros.
    distbounds : tuple or None
        Integration bounds (only used if analytical moments are unavailable).

    Returns
    -------
    float
    """
    need_coef = stat in ("cvar", "skew", "kurt")
    m = compute_moments(dist, distarg, p0=p0,
                        raw=False, central=True, coef=need_coef,
                        distbounds=distbounds)

    mu = m["mu"]
    if stat == "mean":
        return float(mu["mu1"])
    if stat == "sd":
        return float(np.sqrt(mu["mu2"]))
    if stat == "var":
        return float(mu["mu2"])
    if stat == "cvar":
        return float(m["coefficients"]["cv"])
    if stat == "skew":
        return float(m["coefficients"]["cs"])
    if stat == "kurt":
        return float(m["coefficients"]["ck"])
    raise ValueError(f"Unknown stat '{stat}'. Choose from: mean, sd, var, cvar, skew, kurt.")
