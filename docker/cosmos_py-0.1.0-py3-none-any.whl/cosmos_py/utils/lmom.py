
"""
lmom.py

Cálculo de momentos-L: media L, L-varianza, L-asimetría, L-curtosis.
"""
import numpy as np
from scipy.special import comb


def l_moments(x, r=4):
    x = np.sort(x)
    n = len(x)
    b = []

    for r_ in range(r):
        coeffs = [((-1)**(k - r_)) * comb(r_, k) * np.mean(x[k:]) for k in range(r_ + 1)]
        b_r = sum(coeffs)
        b.append(b_r)

    l1 = b[0]
    l2 = b[1]
    t3 = b[2] / b[1] if b[1] != 0 else np.nan
    t4 = b[3] / b[1] if b[1] != 0 else np.nan

    return {
        'L1': l1,
        'L2': l2,
        'T3': t3,
        'T4': t4
    }
