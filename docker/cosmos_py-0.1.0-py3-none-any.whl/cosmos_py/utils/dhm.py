"""
DHM circulant-embedding algorithm for fast Gaussian process simulation.

Port of DHMgenSj and DHMgenSim from R's utils-internal.R.
Reference: Dietrich & Newsam (1997), Haskard (2007).
"""
import numpy as np


def dhm_gen_sj(acvf):
    """
    Compute one-sided spectral values Sj from an autocovariance vector.

    Parameters
    ----------
    acvf : array-like, shape (MM+1,)
        Autocovariance values at lags 0, 1, ..., MM.

    Returns
    -------
    Sj : ndarray, shape (MM+1,)
        Non-negative spectral values.
    """
    acvf = np.asarray(acvf, dtype=float)
    MM = len(acvf) - 1
    # Circulant embedding: [acvf, rev(acvf[1:MM])]  (length 2*MM)
    circ = np.concatenate([acvf, acvf[1:MM][::-1]])
    Sj = np.real(np.fft.fft(circ))[:MM + 1]
    Sj = np.abs(Sj)
    if not np.all(Sj >= 0):
        raise ValueError("some of the S_j values are negative")
    return Sj


def dhm_gen_sim(Sj, rn=None):
    """
    Simulate one realisation of a stationary Gaussian process via DHM.

    Parameters
    ----------
    Sj : ndarray
        Spectral values from dhm_gen_sj.
    rn : ndarray or None
        Standard normal random numbers of length 2*len(Sj)-2.
        Generated internally if None.

    Returns
    -------
    ndarray, shape (len(Sj)-1,)
        One realisation of the Gaussian process (length N = len(Sj)-1).
    """
    Sj = np.asarray(Sj, dtype=float)
    N = len(Sj) - 1          # N = MM / 2  where MM = 2*(len(Sj)-1)
    M = 2 * N                # length of the full circulant vector

    if rn is None:
        rn = np.random.randn(M)
    rn = np.asarray(rn, dtype=float)

    # Build Yj: complex half-spectrum (length N+1)
    Yj = np.zeros(N + 1, dtype=complex)
    Yj[0] = np.sqrt(Sj[0]) * rn[0]          # real, index 0
    Yj[N] = np.sqrt(Sj[N]) * rn[M - 1]     # real, index N

    # Interior complex entries: Python 0-based k = 1,...,N-1
    # R: rn[2*(1:(N-1))]   (1-indexed) → Python: rn[2k-1] for k=1,...,N-1
    # R: rn[2*(1:(N-1))+1] (1-indexed) → Python: rn[2k]   for k=1,...,N-1
    k = np.arange(1, N)
    Yj[k] = np.sqrt(0.5 * Sj[k]) * (rn[2 * k - 1] + 1j * rn[2 * k])

    # Build full DFT input and extract first N values
    full = np.concatenate([Yj, np.conj(Yj[1:N][::-1])])
    return np.real(np.fft.fft(full))[:N] / np.sqrt(M)
