
"""
stratify_data.py

Estratifica datos por cuantiles definidos de una variable (por ejemplo, precipitación).
"""
import pandas as pd


def stratify_data(df, value_col='value', n_quantiles=4):
    quantiles = pd.qcut(df[value_col], q=n_quantiles, labels=False)
    df['strata'] = quantiles
    return df
