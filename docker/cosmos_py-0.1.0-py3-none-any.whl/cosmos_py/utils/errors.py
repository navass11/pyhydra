
"""
errors.py

Funciones para calcular métricas de error.
"""
import numpy as np


def rmse(obs, sim):
    return np.sqrt(np.mean((np.array(obs) - np.array(sim)) ** 2))


def mae(obs, sim):
    return np.mean(np.abs(np.array(obs) - np.array(sim)))
