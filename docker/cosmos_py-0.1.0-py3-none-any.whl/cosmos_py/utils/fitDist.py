import numpy as np
from scipy.optimize import minimize

from cosmos_py.utils.ecdf import compute_ecdf


# ── Distribution registry ─────────────────────────────────────────────────────
# Each entry: params (ordered list), start (initial values), log_transform
# (True = parameter must be positive → optimize in log space).

_DIST_REGISTRY = {
    "gengamma": {
        "params":        ["scale", "shape1", "shape2"],
        "start":         [1.0, 0.5, 0.5],
        "log_transform": [True, True, True],
    },
    "paretoII": {
        "params":        ["scale", "shape"],
        "start":         [1.0, 0.3],
        "log_transform": [True, True],
    },
    "burrXII": {
        "params":        ["scale", "shape1", "shape2"],
        "start":         [1.0, 1.0, 0.5],
        "log_transform": [True, True, True],
    },
    "burrIII": {
        "params":        ["scale", "shape1", "shape2"],
        "start":         [1.0, 1.0, 0.5],
        "log_transform": [True, True, True],
    },
    "gev": {
        "params":        ["loc", "scale", "shape"],
        "start":         [0.0, 1.0, 0.1],
        "log_transform": [False, True, False],
    },
    "lnorm": {
        "params":        ["meanlog", "sdlog"],
        "start":         [0.0, 1.0],
        "log_transform": [False, True],
    },
}


def get_dist_args(dist_name):
    if dist_name not in _DIST_REGISTRY:
        raise ValueError(
            f"Distribution '{dist_name}' not in registry. "
            f"Available: {list(_DIST_REGISTRY)}"
        )
    return _DIST_REGISTRY[dist_name]["params"]


def _cdf(dist, params_dict, x):
    if dist == "gengamma":
        from cosmos_py.distributions.ggamma import pggamma
        return pggamma(x, **params_dict)
    if dist == "paretoII":
        from cosmos_py.distributions.paretoII import pparetoII
        return pparetoII(x, **params_dict)
    if dist == "burrXII":
        from cosmos_py.distributions.burrXII import pburrXII
        return pburrXII(x, **params_dict)
    if dist == "burrIII":
        from cosmos_py.distributions.burrIII import pburrIII
        return pburrIII(x, **params_dict)
    if dist == "gev":
        from cosmos_py.distributions.gev import pgev
        return pgev(x, **params_dict)
    if dist == "lnorm":
        import scipy.stats as _st
        return _st.lognorm.cdf(x, s=params_dict["sdlog"], scale=np.exp(params_dict["meanlog"]))
    raise ValueError(f"Unknown distribution: {dist}")


def _ppf(dist, params_dict, p):
    if dist == "gengamma":
        from cosmos_py.distributions.ggamma import qggamma
        return qggamma(p, **params_dict)
    if dist == "paretoII":
        from cosmos_py.distributions.paretoII import qparetoII
        return qparetoII(p, **params_dict)
    if dist == "burrXII":
        from cosmos_py.distributions.burrXII import qburrXII
        return qburrXII(p, **params_dict)
    if dist == "burrIII":
        from cosmos_py.distributions.burrIII import qburrIII
        return qburrIII(p, **params_dict)
    if dist == "gev":
        from cosmos_py.distributions.gev import qgev
        return qgev(p, **params_dict)
    if dist == "lnorm":
        import scipy.stats as _st
        return _st.lognorm.ppf(p, s=params_dict["sdlog"], scale=np.exp(params_dict["meanlog"]))
    raise ValueError(f"Unknown distribution: {dist}")


def _rMSE(x, y):
    """Ratio mean squared error: sum((x/y - 1)^2) / n"""
    return float(np.sum(((x / y) - 1.0) ** 2) / len(y))


def _MSE(x, y):
    """Mean squared error: sum((x - y)^2) / n"""
    return float(np.sum((x - y) ** 2) / len(y))


def _decode(raw_par, log_transform):
    """Inverse-transform optimizer parameters back to distribution parameters."""
    par = np.empty_like(raw_par)
    for i, lt in enumerate(log_transform):
        par[i] = np.exp(raw_par[i]) if lt else raw_par[i]
    return par


def _encode(par, log_transform):
    """Transform distribution parameters to optimizer space."""
    raw = np.empty_like(par, dtype=float)
    for i, lt in enumerate(log_transform):
        raw[i] = np.log(max(par[i], 1e-10)) if lt else par[i]
    return raw


def _norm_objective(raw_par, ecdf_x, ecdf_p, dist, norm, log_transform):
    """
    Fitting norm N1–N4, operating on log-transformed parameters.

    N1: rMSE on quantiles  — sum((F/FN - 1)^2) / n
    N2: MSE  on quantiles  — sum((F  - FN)^2) / n
    N3: rMSE on probs      — sum((Xu/Xi - 1)^2) / n
    N4: MSE  on probs      — sum((Xu - Xi)^2) / n
    """
    par = _decode(raw_par, log_transform)
    param_names = _DIST_REGISTRY[dist]["params"]
    params_dict = dict(zip(param_names, par))

    try:
        if norm in ("N1", "N2"):
            F = np.asarray(_ppf(dist, params_dict, ecdf_p), dtype=float)
            FN = ecdf_x
            if not np.all(np.isfinite(F)) or np.any(F <= 0):
                return 1e10
            return _rMSE(F, FN) if norm == "N1" else _MSE(F, FN)

        if norm in ("N3", "N4"):
            Xu = np.asarray(_cdf(dist, params_dict, ecdf_x), dtype=float)
            Xi = ecdf_p
            if not np.all(np.isfinite(Xu)):
                return 1e10
            return _rMSE(Xu, Xi) if norm == "N3" else _MSE(Xu, Xi)

    except Exception:
        return 1e10

    return 1e10


def fit_dist(data, dist, n_points=30, norm_type="N1", opts=None):
    """
    Fit a parametric distribution to *data* by minimising a fitting norm.

    Parameters
    ----------
    data : array-like
        Observed non-zero values.
    dist : str
        Distribution name (``"gengamma"``, ``"paretoII"``, ``"burrXII"``,
        ``"burrIII"``, ``"gev"``).
    n_points : int
        Number of ECDF points used in the norm.
    norm_type : str
        One of ``"N1"`` (rMSE on quantiles), ``"N2"`` (MSE on quantiles),
        ``"N3"`` (rMSE on probs), ``"N4"`` (MSE on probs).
    opts : dict or None
        Options forwarded to ``scipy.optimize.minimize`` (Nelder-Mead).

    Returns
    -------
    dict with keys ``params``, ``params_dict``, ``edf``, ``objective``,
    ``dist``, ``data``.
    """
    if opts is None:
        opts = {"maxiter": 20000, "xatol": 1e-8, "fatol": 1e-8}

    data = np.asarray(data, dtype=float)
    data = data[np.isfinite(data) & (data > 0)]

    ecdf = compute_ecdf(data)
    x_all, p_all = ecdf["x"], ecdf["p"]

    n = len(x_all)
    if n > n_points:
        idx = np.linspace(0, n - 1, n_points).astype(int)
        idx = np.unique(idx)
    else:
        idx = np.arange(n)

    ecdf_x = x_all[idx]
    ecdf_p = np.clip(p_all[idx], 1e-10, 1 - 1e-10)

    reg = _DIST_REGISTRY[dist]
    start = np.array(reg["start"], dtype=float)
    log_transform = reg["log_transform"]

    raw_start = _encode(start, log_transform)

    result = minimize(
        _norm_objective,
        raw_start,
        args=(ecdf_x, ecdf_p, dist, norm_type, log_transform),
        method="Nelder-Mead",
        options=opts,
    )

    params_arr = _decode(result.x, log_transform)
    param_names = reg["params"]
    params_dict = dict(zip(param_names, params_arr))

    return {
        "params": params_arr,
        "params_dict": params_dict,
        "edf": ecdf,
        "objective": float(result.fun),
        "dist": dist,
        "data": data,
    }
